﻿import 'package:flutter/material.dart';
import '../services/database_helper.dart';
import 'resultado_juego_seccion.dart';

const Color _colorFondoOscuro = Color(0xFF14171C);
const Color _colorAcento = Color(0xFF0ABDCF);

class RegistrarJuegoScreen extends StatefulWidget {
  final int bateadorId;
  final String nombreBateador;

  const RegistrarJuegoScreen({
    super.key,
    required this.bateadorId,
    required this.nombreBateador,
  });

  @override
  State<RegistrarJuegoScreen> createState() => _RegistrarJuegoScreenState();
}

class _RegistrarJuegoScreenState extends State<RegistrarJuegoScreen> {
  DateTime _fecha = DateTime.now();
  bool _guardando = false;
  final _resultado = ResultadoJuegoController();

  static const List<List<String>> _campos = [
    ['turnos', 'Turnos al bate'],
    ['hits', 'Hits'],
    ['dobles', 'Dobles (2B)'],
    ['triples', 'Triples (3B)'],
    ['homeRuns', 'Home runs'],
    ['impulsadas', 'Impulsadas (CI)'],
    ['anotadas', 'Anotadas (CA)'],
    ['ponches', 'Ponches (K)'],
    ['basesPorBolas', 'Bases por bolas (BB)'],
  ];

  late final Map<String, TextEditingController> _ctrl = {
    for (final c in _campos) c[0]: TextEditingController(),
  };

  @override
  void dispose() {
    for (final c in _ctrl.values) {
      c.dispose();
    }
    _resultado.dispose();
    super.dispose();
  }

  String _fechaIso(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  String _fechaVista(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';

  Future<void> _elegirFecha() async {
    final elegida = await showDatePicker(
      context: context,
      initialDate: _fecha,
      firstDate: DateTime(2000),
      lastDate: DateTime.now().add(const Duration(days: 1)),
    );
    if (elegida != null) setState(() => _fecha = elegida);
  }

  void _mensaje(String texto) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(texto)));
  }

  Future<void> _guardar() async {
    final v = <String, int>{};
    for (final c in _campos) {
      final txt = _ctrl[c[0]]!.text.trim();
      final n = txt.isEmpty ? 0 : int.tryParse(txt);
      if (n == null || n < 0) {
        _mensaje('"${c[1]}" debe ser un número entero mayor o igual a 0.');
        return;
      }
      v[c[0]] = n;
    }

    if (v['turnos']! == 0 && v['basesPorBolas']! == 0) {
      _mensaje('Ingresa al menos los turnos al bate o las bases por bolas.');
      return;
    }
    if (v['hits']! > v['turnos']!) {
      _mensaje('Los hits no pueden superar los turnos al bate.');
      return;
    }
    if (v['dobles']! + v['triples']! + v['homeRuns']! > v['hits']!) {
      _mensaje('2B + 3B + HR no pueden superar los hits.');
      return;
    }
    if (v['ponches']! > v['turnos']!) {
      _mensaje('Los ponches no pueden superar los turnos al bate.');
      return;
    }

    final errorResultado = _resultado.validar();
    if (errorResultado != null) {
      _mensaje(errorResultado);
      return;
    }

    setState(() => _guardando = true);
    try {
      await DatabaseHelper.instance.registrarJuegoBateador(
        bateadorId: widget.bateadorId,
        fecha: _fechaIso(_fecha),
        equipoRivalId: _resultado.rivalId,
        carrerasPropias: _resultado.carrerasPropias,
        carrerasRival: _resultado.carrerasRival,
        turnos: v['turnos']!,
        hits: v['hits']!,
        dobles: v['dobles']!,
        triples: v['triples']!,
        homeRuns: v['homeRuns']!,
        impulsadas: v['impulsadas']!,
        anotadas: v['anotadas']!,
        ponches: v['ponches']!,
        basesPorBolas: v['basesPorBolas']!,
      );
      if (!mounted) return;
      Navigator.pop(context, true);
    } on StateError catch (e) {
      if (!mounted) return;
      setState(() => _guardando = false);
      _mensaje(e.message);
    } catch (e) {
      if (!mounted) return;
      setState(() => _guardando = false);
      _mensaje('No se pudo guardar el juego: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final ancho = (MediaQuery.of(context).size.width - 16 * 2 - 12) / 2;

    return Scaffold(
      backgroundColor: const Color(0xFFF2F4F7),
      appBar: AppBar(
        backgroundColor: _colorFondoOscuro,
        foregroundColor: Colors.white,
        title: const Text('REGISTRAR JUEGO'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(
            widget.nombreBateador,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          InkWell(
            onTap: _elegirFecha,
            child: InputDecorator(
              decoration: const InputDecoration(
                labelText: 'Fecha del juego',
                border: OutlineInputBorder(),
                suffixIcon: Icon(Icons.calendar_today),
                filled: true,
                fillColor: Colors.white,
              ),
              child: Text(_fechaVista(_fecha)),
            ),
          ),
          const SizedBox(height: 16),
          ResultadoJuegoSeccion(controller: _resultado),
          const SizedBox(height: 16),
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: [
              for (final c in _campos)
                SizedBox(
                  width: ancho,
                  child: TextField(
                    controller: _ctrl[c[0]],
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: c[1],
                      border: const OutlineInputBorder(),
                      filled: true,
                      fillColor: Colors.white,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 24),
          SizedBox(
            height: 48,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: _colorAcento,
                foregroundColor: Colors.white,
              ),
              onPressed: _guardando ? null : _guardar,
              child: _guardando
                  ? const SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    )
                  : const Text('GUARDAR JUEGO', style: TextStyle(fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );
  }
}
