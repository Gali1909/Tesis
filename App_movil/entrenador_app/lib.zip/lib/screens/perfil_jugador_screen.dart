﻿import 'equipos_anteriores_card.dart';
import 'dart:io';
import 'package:flutter/material.dart';
import '../models/jugador.dart';
import '../models/equipo.dart';
import '../models/lanzador_perfil.dart';
import '../models/lanzador_perfil_historico.dart';
import '../models/bateador_perfil.dart';
import '../models/lanzador_tipo_picheo.dart';
import '../models/bateador_vulnerabilidad.dart';
import '../models/lanzador_rol.dart';
import '../models/jugador_posicion.dart';
import '../services/database_helper.dart';
import 'perfil_bateador_screen.dart';
import 'cargar_lanzador_perfil_screen.dart';
import 'cargar_lanzador_perfil_historico_screen.dart';
import 'registrar_salida_screen.dart';
import 'historial_salidas_screen.dart';
import 'editar_jugador_screen.dart';
import 'cargar_tipo_picheo_screen.dart';

const Color _colorFondoOscuro = Color(0xFF14171C);
const Color _colorAcento = Color(0xFF0ABDCF);
const Color _colorNaranja = Color(0xFFE36F10);
const List<Color> _paletaPitches = [
  Color(0xFF0ABDCF),
  Color(0xFFE36F10),
  Color(0xFF4C6FFF),
  Color(0xFF2ECC71),
];

class PerfilJugadorScreen extends StatefulWidget {
  final Jugador jugador;

  const PerfilJugadorScreen({super.key, required this.jugador});

  @override
  State<PerfilJugadorScreen> createState() => _PerfilJugadorScreenState();
}

class _PerfilJugadorScreenState extends State<PerfilJugadorScreen> {
  late Jugador _jugadorActual;
  Equipo? _equipo;
  LanzadorPerfil? _lanzadorPerfil;
  LanzadorPerfilHistorico? _lanzadorPerfilHistorico;
  List<int> _temporadasDisponibles = [];
  int? _temporadaSeleccionada;
  BateadorPerfil? _bateadorPerfil;
  List<LanzadorTipoPicheo> _tiposPicheo = [];
  List<BateadorVulnerabilidad> _vulnerabilidades = [];
  List<LanzadorRol> _rolesLanzador = [];
  int _vistaSalidas = 0; // 0 = temporada, 5/10/15 = ultimas salidas
  Map<String, dynamic>? _statsUltimas;
  List<JugadorPosicion> _posiciones = [];
  bool _cargando = true;
  bool _mostrarDetalles = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _jugadorActual = widget.jugador;
    _cargarDatos();
  }

  Future<void> _cargarDatos() async {
    final id = widget.jugador.jugadorId!;

    try {
      final equipo = widget.jugador.equipoId == null
          ? null
          : await DatabaseHelper.instance.obtenerEquipoPorId(widget.jugador.equipoId!);

      if (widget.jugador.rol == 'lanzador') {
        final temporadas = await DatabaseHelper.instance.obtenerTemporadasLanzadorTotal(id);
        final historico = await DatabaseHelper.instance.obtenerLanzadorPerfilHistorico(id);
        final tipos = await DatabaseHelper.instance.obtenerTiposPicheo(id);
        final roles = await DatabaseHelper.instance.obtenerRolesLanzador(id);

        LanzadorPerfil? perfilTemporada;
        int? temporadaInicial;
        if (temporadas.isNotEmpty) {
          temporadaInicial = (_temporadaSeleccionada != null && temporadas.contains(_temporadaSeleccionada))
              ? _temporadaSeleccionada!
              : temporadas.first;
          perfilTemporada = await DatabaseHelper.instance.obtenerLanzadorPerfilTotal(id, temporadaInicial);
        }

        setState(() {
          _equipo = equipo;
          _temporadasDisponibles = temporadas;
          _temporadaSeleccionada = temporadaInicial;
          _lanzadorPerfil = perfilTemporada;
          _lanzadorPerfilHistorico = historico;
          _tiposPicheo = tipos;
          _rolesLanzador = roles;
          _cargando = false;
        });
      } else {
        final perfil = await DatabaseHelper.instance.obtenerBateadorPerfil(id);
        final vulnerabilidades = await DatabaseHelper.instance.obtenerVulnerabilidades(id);
        final posiciones = await DatabaseHelper.instance.obtenerPosiciones(id);
        setState(() {
          _equipo = equipo;
          _bateadorPerfil = perfil;
          _vulnerabilidades = vulnerabilidades;
          _posiciones = posiciones;
          _cargando = false;
        });
      }
    } catch (e) {
      setState(() {
        _error = e.toString();
        _cargando = false;
      });
    }
  }

  Future<void> _abrirRegistrarSalida() async {
    final ok = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (context) => RegistrarSalidaScreen(
          lanzadorId: widget.jugador.jugadorId!,
          nombreLanzador: widget.jugador.nombre,
        ),
      ),
    );
    if (ok == true) {
      await _cargarDatos();
      await _recargarUltimas();
    }
  }

  Future<void> _abrirHistorialSalidas() async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => HistorialSalidasScreen(
          lanzadorId: widget.jugador.jugadorId!,
          nombreLanzador: widget.jugador.nombre,
        ),
      ),
    );
    await _cargarDatos();
    await _recargarUltimas();
  }

  Future<void> _recargarUltimas() async {
    if (_vistaSalidas == 0) return;
    final s = await DatabaseHelper.instance
        .ultimasSalidasLanzador(widget.jugador.jugadorId!, _vistaSalidas);
    if (!mounted) return;
    setState(() => _statsUltimas = s);
  }

  Future<void> _cambiarVistaSalidas(int nueva) async {
    if (nueva == _vistaSalidas) return;
    final s = nueva == 0
        ? null
        : await DatabaseHelper.instance
            .ultimasSalidasLanzador(widget.jugador.jugadorId!, nueva);
    if (!mounted) return;
    setState(() {
      _vistaSalidas = nueva;
      _statsUltimas = s;
    });
  }

  Future<void> _cambiarTemporada(int? nuevaTemporada) async {
    if (nuevaTemporada == null || nuevaTemporada == _temporadaSeleccionada) return;
    final id = widget.jugador.jugadorId!;
    final perfil = await DatabaseHelper.instance.obtenerLanzadorPerfilTotal(id, nuevaTemporada);
    setState(() {
      _temporadaSeleccionada = nuevaTemporada;
      _lanzadorPerfil = perfil;
    });
  }

  Future<void> _abrirFormularioCarga() async {
    final id = widget.jugador.jugadorId!;
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CargarLanzadorPerfilScreen(
          lanzadorId: id,
          temporadaInicial: _temporadaSeleccionada,
        ),
      ),
    );
    await _cargarDatos();
  }

  Future<void> _abrirFormularioHistorico() async {
    final id = widget.jugador.jugadorId!;
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CargarLanzadorPerfilHistoricoScreen(lanzadorId: id),
      ),
    );
    await _cargarDatos();
  }

  Future<void> _abrirFormularioEditarPerfil() async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => EditarJugadorScreen(jugador: _jugadorActual),
      ),
    );
    final actualizado = await DatabaseHelper.instance.obtenerJugadorPorId(widget.jugador.jugadorId!);
    if (actualizado != null && mounted) {
      setState(() => _jugadorActual = actualizado);
    }
    await _cargarDatos();
  }

  Future<void> _abrirFormularioTipoPicheo({LanzadorTipoPicheo? existente}) async {
    final id = widget.jugador.jugadorId!;
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CargarTipoPicheoScreen(
          lanzadorId: id,
          existente: existente,
        ),
      ),
    );
    await _cargarDatos();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.jugador.rol != 'lanzador') {
      return PerfilBateadorScreen(jugador: widget.jugador);
    }
    return Scaffold(
      backgroundColor: const Color(0xFFF2F4F7),
      appBar: AppBar(
        backgroundColor: _colorFondoOscuro,
        foregroundColor: Colors.white,
        title: Text(_jugadorActual.nombre),
      ),
      body: _cargando
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Text('Error cargando datos: $_error'),
                  ),
                )
              : widget.jugador.rol == 'lanzador'
                  ? _vistaLanzador()
                  : _vistaBateador(),
    );
  }

  Widget _vistaLanzador() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _tarjetaPerfilLanzador(),
        const SizedBox(height: 16),
        _botonesAccion(),
        const SizedBox(height: 16),
        _pitchesDestacados(),
        const SizedBox(height: 16),
        _tarjetaProximamente(
          'Registro de partidos',
          Icons.sports_score,
          'Se llenara con los datos de juegos individuales cuando esa pantalla este lista.',
        ),
        const SizedBox(height: 16),
        _tarjetaProximamente(
          'Performance actual',
          Icons.show_chart,
          'Graficas de velocidad y precision por juego, cuando existan datos juego por juego.',
        ),
        EquiposAnterioresCard(jugadorId: widget.jugador.jugadorId!),
        if (_mostrarDetalles) ...[
          const SizedBox(height: 20),
          const Divider(),
          const SizedBox(height: 8),
          const Text('Temporada', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 8),
          _selectorTemporada(),
          const SizedBox(height: 16),
          const Text('Estadisticas de la temporada', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 8),
          _lanzadorPerfil == null
              ? const Text('Sin estadisticas cargadas para esta temporada')
              : _tablaEstadisticasLanzador(_lanzadorPerfil!),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Estadisticas de por vida', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              IconButton(
                icon: const Icon(Icons.edit, size: 20),
                tooltip: 'Editar estadisticas de por vida',
                onPressed: _abrirFormularioHistorico,
              ),
            ],
          ),
          _lanzadorPerfilHistorico == null
              ? const Text('Sin estadisticas historicas cargadas todavia')
              : _tablaEstadisticasHistorico(_lanzadorPerfilHistorico!),
          const SizedBox(height: 16),
          const Text('Detalle de tipos de lanzamiento', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 8),
          _tiposPicheo.isEmpty
              ? const Text('Sin tipos de lanzamiento cargados todavia')
              : Column(children: _tiposPicheo.map((t) => _filaTipoPicheo(t)).toList()),
        ],
      ],
    );
  }

  Widget _vistaBateador() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _tarjetaInfoBasica(),
        const SizedBox(height: 16),
        if (_posiciones.isNotEmpty) ...[
          const Text('Posiciones', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          Wrap(
            spacing: 8,
            children: _posiciones
                .map((p) => Chip(label: Text(p.posicion)))
                .toList(),
          ),
          const SizedBox(height: 16),
        ],
        const Text('Estadisticas generales', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        const SizedBox(height: 8),
        _bateadorPerfil == null
            ? const Text('Sin estadisticas cargadas todavia')
            : _tablaEstadisticasBateador(_bateadorPerfil!),
        const SizedBox(height: 16),
        const Text('Vulnerabilidades', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        const SizedBox(height: 8),
        _vulnerabilidades.isEmpty
            ? const Text('Sin vulnerabilidades cargadas todavia')
            : Column(
                children: _vulnerabilidades.map((v) => _filaVulnerabilidad(v)).toList(),
              ),
      ],
    );
  }

  // ---------- Widgets nuevos del rediseno (lanzador) ----------

  String? _abreviaturaMano() {
    final mano = _jugadorActual.manoLanzamiento?.toLowerCase();
    if (mano == 'derecho') return 'RHP';
    if (mano == 'zurdo') return 'LHP';
    return null;
  }
  Widget _tarjetaPerfilLanzador() {
    final rolPrincipal = _rolesLanzador.isNotEmpty ? _rolesLanzador.first.rolLanzador.toUpperCase() : null;
    final rolesSecundarios = _rolesLanzador.length > 1 ? _rolesLanzador.skip(1).toList() : <LanzadorRol>[];
    final fotoPath = _jugadorActual.foto;
    final tieneFoto = fotoPath != null && fotoPath.isNotEmpty && File(fotoPath).existsSync();

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(color: Colors.black.withValues(alpha: 0.08), blurRadius: 12, offset: const Offset(0, 4)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 32,
                backgroundColor: _colorAcento.withValues(alpha: 0.15),
                backgroundImage: tieneFoto ? FileImage(File(fotoPath)) : null,
                child: tieneFoto ? null : const Icon(Icons.person, size: 32, color: _colorAcento),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _jugadorActual.nombre.toUpperCase(),
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: _colorFondoOscuro),
                    ),
                    if (rolPrincipal != null || _abreviaturaMano() != null)
                      Padding(
                        padding: const EdgeInsets.only(top: 2),
                        child: Row(
                          children: [
                            if (rolPrincipal != null)
                              Text(
                                rolPrincipal,
                                style: const TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                  color: _colorNaranja,
                                  letterSpacing: 0.5,
                                ),
                              ),
                            if (rolPrincipal != null && _abreviaturaMano() != null)
                              const SizedBox(width: 8),
                            if (_abreviaturaMano() != null)
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                                decoration: BoxDecoration(
                                  color: _colorAcento.withValues(alpha: 0.15),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Text(
                                  _abreviaturaMano()!,
                                  style: const TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.bold,
                                    color: _colorAcento,
                                  ),
                                ),
                              ),
                          ],
                        ),
                      ),
                    if (_equipo != null)
                      Padding(
                        padding: const EdgeInsets.only(top: 2),
                        child: Text(
                          _equipo!.nombre.toUpperCase(),
                          style: const TextStyle(fontSize: 12, color: Colors.grey),
                        ),
                      ),
                    if (rolesSecundarios.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 6),
                        child: Wrap(
                          spacing: 6,
                          children: rolesSecundarios
                              .map((r) => Chip(
                                    label: Text(r.rolLanzador, style: const TextStyle(fontSize: 10)),
                                    padding: EdgeInsets.zero,
                                    materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                                    visualDensity: VisualDensity.compact,
                                  ))
                              .toList(),
                        ),
                      ),
                  ],
                ),
              ),
              if (_jugadorActual.numero != null)
                Padding(
                  padding: const EdgeInsets.only(left: 8),
                  child: Text.rich(
                    TextSpan(
                      children: [
                        const TextSpan(
                          text: '#',
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: _colorNaranja),
                        ),
                        TextSpan(
                          text: _jugadorActual.numero.toString(),
                          style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w800, color: _colorAcento),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
          ),
          const SizedBox(height: 16),
          _filaStatsPrincipales(),
        ],
      ),
    );
  }

  Widget _selectorVistaSalidas() {
    const opciones = [
      [0, 'Temporada'],
      [5, 'Ultimas 5'],
      [10, 'Ultimas 10'],
      [15, 'Ultimas 15'],
    ];
    return Wrap(
      spacing: 8,
      children: [
        for (final o in opciones)
          ChoiceChip(
            label: Text(o[1] as String),
            selected: _vistaSalidas == o[0],
            selectedColor: _colorAcento,
            labelStyle: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: _vistaSalidas == o[0] ? Colors.white : Colors.black87,
            ),
            onSelected: (_) => _cambiarVistaSalidas(o[0] as int),
          ),
      ],
    );
  }

  Widget _filaStatsUltimas() {
    final s = _statsUltimas;
    if (s == null || (s['salidas'] as int) == 0) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 12),
        child: Text(
          'Sin salidas registradas todavia. Usa REGISTRAR SALIDA.',
          style: TextStyle(color: Colors.black54, fontSize: 12),
        ),
      );
    }
    final salidas = s['salidas'] as int;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          salidas < _vistaSalidas
              ? 'Solo hay $salidas salida(s) registrada(s)'
              : 'Ultimas $salidas salidas registradas',
          style: const TextStyle(color: Colors.black54, fontSize: 12),
        ),
        const SizedBox(height: 4),
        SizedBox(
          height: 62,
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                _estadisticaCompacta('ERA', (s['era'] as double).toStringAsFixed(2)),
                _estadisticaCompacta('WHIP', (s['whip'] as double).toStringAsFixed(2)),
                _estadisticaCompacta('K/9', (s['k9'] as double).toStringAsFixed(1)),
                _estadisticaCompacta('IP', s['ip'].toString()),
                _estadisticaCompacta('H', s['h'].toString()),
                _estadisticaCompacta('CL', s['cl'].toString()),
                _estadisticaCompacta('SO', s['k'].toString()),
                _estadisticaCompacta('BB', s['bb'].toString()),
                _estadisticaCompacta('PIT', s['picheos'].toString()),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _filaStatsPrincipales() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        _selectorVistaSalidas(),
        const SizedBox(height: 8),
        _vistaSalidas == 0 ? _filaStatsTemporada() : _filaStatsUltimas(),
      ],
    );
  }

  Widget _filaStatsTemporada() {
    final p = _lanzadorPerfil;
    final era = p?.efectividad?.toStringAsFixed(2) ?? '--';
    final wl = p == null ? '--' : '${p.juegosGanados}-${p.juegosPerdidos}';
    final so = p?.ponches.toString() ?? '--';
    final whip = p?.whip?.toStringAsFixed(2) ?? '--';
    final aperturas = p?.aperturas.toString() ?? '--';
    final salvados = p?.salvados.toString() ?? '--';
    final juegosLanzados = p?.juegosLanzados.toString() ?? '--';
    final innings = p?.inningsFormato ?? '--';
    final bb = p?.basesPorBolas.toString() ?? '--';
    final hits = p?.hitsPermitidos.toString() ?? '--';
    final cl = p?.carrerasLimpias.toString() ?? '--';

    return SizedBox(
      height: 62,
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            _estadisticaCompacta('ERA', era),
            _estadisticaCompacta('W-L', wl),
            _estadisticaCompacta('SO', so),
            _estadisticaCompacta('WHIP', whip),
            _estadisticaCompacta('AP', aperturas),
            _estadisticaCompacta('SV', salvados),
            _estadisticaCompacta('JL', juegosLanzados),
            _estadisticaCompacta('IP', innings),
            _estadisticaCompacta('BB', bb),
            _estadisticaCompacta('H', hits),
            _estadisticaCompacta('CL', cl),
          ],
        ),
      ),
    );
  }

  Widget _estadisticaCompacta(String etiqueta, String valor) {
    return Container(
      width: 62,
      alignment: Alignment.center,
      margin: const EdgeInsets.only(right: 14),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(etiqueta, style: const TextStyle(fontSize: 11, color: Colors.grey, fontWeight: FontWeight.w600)),
          const SizedBox(height: 4),
          Text(valor, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: _colorFondoOscuro)),
        ],
      ),
    );
  }

  Widget _botonesAccion() {
    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: OutlinedButton(
                style: OutlinedButton.styleFrom(
                  foregroundColor: _colorFondoOscuro,
                  side: const BorderSide(color: _colorFondoOscuro),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                onPressed: _abrirFormularioEditarPerfil,
                child: const Text('EDITAR PERFIL', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 0.5)),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: _colorFondoOscuro,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                onPressed: _abrirFormularioCarga,
                child: const Text('EDITAR ESTADISTICAS', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 0.5)),
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: _colorAcento,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
            onPressed: _abrirRegistrarSalida,
            icon: const Icon(Icons.add),
            label: const Text('REGISTRAR SALIDA', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 0.5)),
          ),
        ),
        const SizedBox(height: 8),
        SizedBox(
          width: double.infinity,
          child: OutlinedButton.icon(
            style: OutlinedButton.styleFrom(
              foregroundColor: _colorAcento,
              side: const BorderSide(color: _colorAcento),
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
            onPressed: _abrirHistorialSalidas,
            icon: const Icon(Icons.history),
            label: const Text('HISTORIAL DE SALIDAS', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 0.5)),
          ),
        ),
        TextButton(
          onPressed: () => setState(() => _mostrarDetalles = !_mostrarDetalles),
          child: Text(
            _mostrarDetalles ? 'OCULTAR ESTADISTICAS COMPLETAS' : 'VER ESTADISTICAS COMPLETAS',
            style: const TextStyle(color: _colorAcento, fontWeight: FontWeight.w600, fontSize: 12, letterSpacing: 0.3),
          ),
        ),
      ],
    );
  }

  Widget _pitchesDestacados() {
    final ordenados = [..._tiposPicheo]
      ..sort((a, b) => (b.frecuencia ?? 0).compareTo(a.frecuencia ?? 0));

    return _tarjetaSeccion(
      titulo: 'Repertorio del lanzador',
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ...ordenados.asMap().entries.map((entry) {
              final i = entry.key;
              final t = entry.value;
              final color = _paletaPitches[i % _paletaPitches.length];
              return InkWell(
                borderRadius: BorderRadius.circular(12),
                onTap: () => _abrirFormularioTipoPicheo(existente: t),
                child: SizedBox(
                  width: 92,
                  child: Column(
                    children: [
                      CircleAvatar(
                        radius: 22,
                        backgroundColor: color.withValues(alpha: 0.15),
                        child: Icon(Icons.sports_baseball, color: color, size: 20),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        t.nombreTipo,
                        textAlign: TextAlign.center,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600),
                      ),
                      Text(
                        t.velocidadPromedio != null ? '${t.velocidadPromedio!.toStringAsFixed(0)}mph' : '--',
                        style: const TextStyle(fontSize: 10, color: Colors.grey),
                      ),
                    ],
                  ),
                ),
              );
            }),
            InkWell(
              customBorder: const CircleBorder(),
              onTap: () => _abrirFormularioTipoPicheo(),
              child: const SizedBox(
                width: 92,
                child: Column(
                  children: [
                    CircleAvatar(
                      radius: 22,
                      backgroundColor: _colorFondoOscuro,
                      child: Icon(Icons.add, color: Colors.white, size: 22),
                    ),
                    SizedBox(height: 6),
                    Text('Agregar', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
  Widget _tarjetaSeccion({required String titulo, required Widget child}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(color: Colors.black.withValues(alpha: 0.06), blurRadius: 10, offset: const Offset(0, 3)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            titulo.toUpperCase(),
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.grey, letterSpacing: 0.5),
          ),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }

  Widget _tarjetaProximamente(String titulo, IconData icono, String detalle) {
    return _tarjetaSeccion(
      titulo: titulo,
      child: Column(
        children: [
          Icon(icono, color: Colors.grey.shade400, size: 32),
          const SizedBox(height: 8),
          Text(detalle, textAlign: TextAlign.center, style: TextStyle(color: Colors.grey.shade500, fontSize: 12)),
        ],
      ),
    );
  }

  // ---------- Widgets existentes ----------

  Widget _tarjetaInfoBasica() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Numero: ${_jugadorActual.numero?.toString() ?? 'N/A'}'),
            if (widget.jugador.rol == 'lanzador')
              Text('Mano: ${_jugadorActual.manoLanzamiento ?? 'N/A'}')
            else
              Text('Mano de bateo: ${_jugadorActual.manoBateo ?? 'N/A'}'),
          ],
        ),
      ),
    );
  }

  Widget _selectorTemporada() {
    if (_temporadasDisponibles.isEmpty) {
      return const Text('Sin temporadas cargadas todavia');
    }
    return DropdownButton<int>(
      value: _temporadaSeleccionada,
      items: _temporadasDisponibles
          .map((t) => DropdownMenuItem(value: t, child: Text(t.toString())))
          .toList(),
      onChanged: _cambiarTemporada,
    );
  }

  Widget _tablaEstadisticasLanzador(LanzadorPerfil p) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Efectividad: ${p.efectividad?.toStringAsFixed(2) ?? 'N/A'}'),
        Text('WHIP: ${p.whip?.toStringAsFixed(2) ?? 'N/A'}'),
        Text('Juegos ganados: ${p.juegosGanados}'),
        Text('Juegos perdidos: ${p.juegosPerdidos}'),
        Text('Aperturas: ${p.aperturas}'),
        Text('Salvados: ${p.salvados}'),
        Text('Juegos lanzados: ${p.juegosLanzados}'),
        Text('Innings lanzados: ${p.inningsFormato}'),
        Text('Ponches: ${p.ponches}'),
        Text('Bases por bolas: ${p.basesPorBolas}'),
        Text('Hits permitidos: ${p.hitsPermitidos}'),
        Text('Carreras limpias: ${p.carrerasLimpias}'),
      ],
    );
  }

  Widget _tablaEstadisticasHistorico(LanzadorPerfilHistorico p) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Efectividad: ${p.efectividad?.toStringAsFixed(2) ?? 'N/A'}'),
        Text('WHIP: ${p.whip?.toStringAsFixed(2) ?? 'N/A'}'),
        Text('Juegos ganados: ${p.juegosGanados}'),
        Text('Juegos perdidos: ${p.juegosPerdidos}'),
        Text('Aperturas: ${p.aperturas}'),
        Text('Salvados: ${p.salvados}'),
        Text('Juegos lanzados: ${p.juegosLanzados}'),
        Text('Innings lanzados: ${p.inningsLanzados}'),
        Text('Ponches: ${p.ponches}'),
        Text('Bases por bolas: ${p.basesPorBolas}'),
        Text('Hits permitidos: ${p.hitsPermitidos}'),
        Text('Carreras limpias: ${p.carrerasLimpias}'),
      ],
    );
  }

  Widget _tablaEstadisticasBateador(BateadorPerfil p) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Promedio de bateo: ${p.promedioBateo?.toStringAsFixed(3) ?? 'N/A'}'),
        Text('Carreras impulsadas: ${p.carrerasImpulsadas}'),
        Text('Carreras anotadas: ${p.carrerasAnotadas}'),
        Text('Home runs: ${p.homeRuns}'),
        Text('Dobles: ${p.dobles}'),
        Text('Triples: ${p.triples}'),
        Text('Hits: ${p.hits}'),
      ],
    );
  }

  Widget _filaTipoPicheo(LanzadorTipoPicheo t) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      title: Text(t.nombreTipo),
      subtitle: Text(
        'Frecuencia: ${t.frecuencia?.toStringAsFixed(1) ?? 'N/A'}% - Velocidad prom: ${t.velocidadPromedio?.toStringAsFixed(1) ?? 'N/A'} mph',
      ),
      trailing: const Icon(Icons.chevron_right, size: 20),
      onTap: () => _abrirFormularioTipoPicheo(existente: t),
    );
  }

  Widget _filaVulnerabilidad(BateadorVulnerabilidad v) {
    return ListTile(
      title: Text(v.nombreTipo),
      subtitle: Text(
        'Efectividad contra: ${v.nivelEfectividadContra?.toStringAsFixed(3) ?? 'N/A'} (${v.origen})',
      ),
    );
  }
}







