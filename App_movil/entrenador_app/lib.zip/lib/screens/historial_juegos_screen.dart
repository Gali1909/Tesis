﻿import 'package:flutter/material.dart';
import '../services/database_helper.dart';

const Color _colorFondoOscuro = Color(0xFF14171C);
const Color _colorAcento = Color(0xFF0ABDCF);

class HistorialJuegosScreen extends StatefulWidget {
  final int bateadorId;
  final String nombreBateador;

  const HistorialJuegosScreen({
    super.key,
    required this.bateadorId,
    required this.nombreBateador,
  });

  @override
  State<HistorialJuegosScreen> createState() => _HistorialJuegosScreenState();
}

class _HistorialJuegosScreenState extends State<HistorialJuegosScreen> {
  List<Map<String, dynamic>> _juegos = [];
  bool _cargando = true;

  @override
  void initState() {
    super.initState();
    _cargar();
  }

  Future<void> _cargar() async {
    final lista = await DatabaseHelper.instance.historialJuegosBateador(widget.bateadorId);
    if (!mounted) return;
    setState(() {
      _juegos = lista;
      _cargando = false;
    });
  }

  int _n(Map<String, dynamic> m, String k) => (m[k] as int?) ?? 0;

  String _fechaVista(String iso) {
    final p = iso.split('-');
    if (p.length != 3) return iso;
    return '${p[2]}/${p[1]}/${p[0]}';
  }

  String _resumenJuego(Map<String, dynamic> j) {
    final rival = j['rival_nombre'] as String?;
    final cp = j['carreras_propias'] as int?;
    final cr = j['carreras_rival'] as int?;
    final partes = <String>[];
    if (rival != null) partes.add('vs $rival');
    if (cp != null && cr != null) partes.add('$cp-$cr');
    return partes.isEmpty ? '' : '   ${partes.join('  ')}';
  }
  Future<void> _borrar(Map<String, dynamic> j) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Borrar juego'),
        content: Text('Se borrara el juego del ${_fechaVista(j['fecha'] as String)}. Esta accion no se puede deshacer.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('CANCELAR')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('BORRAR')),
        ],
      ),
    );
    if (ok != true) return;
    await DatabaseHelper.instance.eliminarJuegoBateador(j['id'] as int);
    await _cargar();
  }

  Future<void> _editar(Map<String, dynamic> j) async {
    final v = await showDialog<Map<String, int>>(
      context: context,
      builder: (ctx) => _EditarJuegoDialog(
        titulo: 'Juego del ${_fechaVista(j['fecha'] as String)}',
        inicial: {
          'turnos': _n(j, 'turnos_al_bate'),
          'hits': _n(j, 'hits_juego'),
          'dobles': _n(j, 'dobles_juego'),
          'triples': _n(j, 'triples_juego'),
          'homeRuns': _n(j, 'home_runs_juego'),
          'impulsadas': _n(j, 'carreras_impulsadas_juego'),
          'anotadas': _n(j, 'carreras_anotadas_juego'),
          'ponches': _n(j, 'ponches_juego'),
          'basesPorBolas': _n(j, 'bases_por_bolas_juego'),
        },
      ),
    );
    if (v == null) return;
    await DatabaseHelper.instance.actualizarJuegoBateador(
      j['id'] as int,
      turnos: v['turnos']!,
      hits: v['hits']!,
      dobles: v['dobles']!,
      triples: v['triples']!,
      homeRuns: v['homeRuns']!,
      impulsadas: v['impulsadas']!,
      anotadas: v['anotadas']!,
      ponches: v['ponches']!,
      basesPorBolas: v['basesPorBolas']!,
    );
    await _cargar();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF2F4F7),
      appBar: AppBar(
        backgroundColor: _colorFondoOscuro,
        foregroundColor: Colors.white,
        title: const Text('HISTORIAL DE JUEGOS'),
      ),
      body: _cargando
          ? const Center(child: CircularProgressIndicator())
          : _juegos.isEmpty
              ? const Center(
                  child: Text('Sin juegos registrados todavia.', style: TextStyle(color: Colors.black54)),
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: _juegos.length + 1,
                  itemBuilder: (ctx, i) {
                    if (i == 0) {
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 8, left: 4),
                        child: Text(
                          '${widget.nombreBateador} - ${_juegos.length} juego(s)',
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                        ),
                      );
                    }
                    final j = _juegos[i - 1];
                    return Card(
                      child: ListTile(
                        title: Text(
                          '${_fechaVista(j['fecha'] as String)}   ${_n(j, 'hits_juego')}-${_n(j, 'turnos_al_bate')}${_resumenJuego(j)}',
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        subtitle: Text(
                          '2B ${_n(j, 'dobles_juego')} | 3B ${_n(j, 'triples_juego')} | HR ${_n(j, 'home_runs_juego')} | '
                          'CI ${_n(j, 'carreras_impulsadas_juego')} | CA ${_n(j, 'carreras_anotadas_juego')} | '
                          'K ${_n(j, 'ponches_juego')} | BB ${_n(j, 'bases_por_bolas_juego')}',
                          style: const TextStyle(fontSize: 12),
                        ),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              icon: const Icon(Icons.edit, color: _colorAcento),
                              onPressed: () => _editar(j),
                            ),
                            IconButton(
                              icon: const Icon(Icons.delete, color: Colors.redAccent),
                              onPressed: () => _borrar(j),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}

class _EditarJuegoDialog extends StatefulWidget {
  final String titulo;
  final Map<String, int> inicial;

  const _EditarJuegoDialog({required this.titulo, required this.inicial});

  @override
  State<_EditarJuegoDialog> createState() => _EditarJuegoDialogState();
}

class _EditarJuegoDialogState extends State<_EditarJuegoDialog> {
  static const List<List<String>> _campos = [
    ['turnos', 'Turnos al bate'],
    ['hits', 'Hits'],
    ['dobles', 'Dobles (2B)'],
    ['triples', 'Triples (3B)'],
    ['homeRuns', 'Home runs'],
    ['impulsadas', 'Impulsadas (CI)'],
    ['anotadas', 'Anotadas (CA)'],
    ['ponches', 'Ponches (K)'],
    ['basesPorBolas', 'Bases por bolas (BB)'],
  ];

  late final Map<String, TextEditingController> _ctrl = {
    for (final c in _campos)
      c[0]: TextEditingController(text: (widget.inicial[c[0]] ?? 0).toString()),
  };
  String? _error;

  @override
  void dispose() {
    for (final c in _ctrl.values) {
      c.dispose();
    }
    super.dispose();
  }

  void _guardar() {
    final v = <String, int>{};
    for (final c in _campos) {
      final txt = _ctrl[c[0]]!.text.trim();
      final n = txt.isEmpty ? 0 : int.tryParse(txt);
      if (n == null || n < 0) {
        setState(() => _error = '"${c[1]}" debe ser un entero mayor o igual a 0.');
        return;
      }
      v[c[0]] = n;
    }
    if (v['hits']! > v['turnos']!) {
      setState(() => _error = 'Los hits no pueden superar los turnos al bate.');
      return;
    }
    if (v['dobles']! + v['triples']! + v['homeRuns']! > v['hits']!) {
      setState(() => _error = '2B + 3B + HR no pueden superar los hits.');
      return;
    }
    if (v['ponches']! > v['turnos']!) {
      setState(() => _error = 'Los ponches no pueden superar los turnos al bate.');
      return;
    }
    Navigator.pop(context, v);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.titulo),
      content: SizedBox(
        width: double.maxFinite,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              for (final c in _campos)
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: TextField(
                    controller: _ctrl[c[0]],
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: c[1],
                      border: const OutlineInputBorder(),
                      isDense: true,
                    ),
                  ),
                ),
              if (_error != null)
                Text(_error!, style: const TextStyle(color: Colors.redAccent, fontSize: 12)),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('CANCELAR')),
        TextButton(onPressed: _guardar, child: const Text('GUARDAR')),
      ],
    );
  }
}
