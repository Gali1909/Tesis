﻿import 'package:flutter/material.dart';
import '../services/database_helper.dart';
import 'registrar_salida_screen.dart' show outsDesdeInnings;

const Color _colorFondoOscuro = Color(0xFF14171C);
const Color _colorAcento = Color(0xFF0ABDCF);

class HistorialSalidasScreen extends StatefulWidget {
  final int lanzadorId;
  final String nombreLanzador;

  const HistorialSalidasScreen({
    super.key,
    required this.lanzadorId,
    required this.nombreLanzador,
  });

  @override
  State<HistorialSalidasScreen> createState() => _HistorialSalidasScreenState();
}

class _HistorialSalidasScreenState extends State<HistorialSalidasScreen> {
  List<Map<String, dynamic>> _salidas = [];
  bool _cargando = true;

  @override
  void initState() {
    super.initState();
    _cargar();
  }

  Future<void> _cargar() async {
    final lista = await DatabaseHelper.instance.historialSalidasLanzador(widget.lanzadorId);
    if (!mounted) return;
    setState(() {
      _salidas = lista;
      _cargando = false;
    });
  }

  int _n(Map<String, dynamic> m, String k) => (m[k] as num?)?.toInt() ?? 0;

  int _outs(Map<String, dynamic> m) =>
      (((m['innings_lanzados_juego'] as num?) ?? 0) * 3).round();

  String _ip(int outs) => '${outs ~/ 3}.${outs % 3}';

  String _fechaVista(String iso) {
    final p = iso.split('-');
    if (p.length != 3) return iso;
    return '${p[2]}/${p[1]}/${p[0]}';
  }

  String _resumenJuego(Map<String, dynamic> j) {
    final rival = j['rival_nombre'] as String?;
    final cp = j['carreras_propias'] as int?;
    final cr = j['carreras_rival'] as int?;
    final partes = <String>[];
    if (rival != null) partes.add('vs $rival');
    if (cp != null && cr != null) partes.add('$cp-$cr');
    return partes.isEmpty ? '' : '   ${partes.join('  ')}';
  }
  Future<void> _borrar(Map<String, dynamic> s) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Borrar salida'),
        content: Text('Se borrara la salida del ${_fechaVista(s['fecha'] as String)}. Esta accion no se puede deshacer.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('CANCELAR')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('BORRAR')),
        ],
      ),
    );
    if (ok != true) return;
    await DatabaseHelper.instance.eliminarSalidaLanzador(s['id'] as int);
    await _cargar();
  }

  Future<void> _editar(Map<String, dynamic> s) async {
    final v = await showDialog<Map<String, int>>(
      context: context,
      builder: (ctx) => _EditarSalidaDialog(
        titulo: 'Salida del ${_fechaVista(s['fecha'] as String)}',
        inningsInicial: _ip(_outs(s)),
        inicial: {
          'picheos': _n(s, 'picheos_lanzados'),
          'carreras': _n(s, 'carreras_permitidas'),
          'limpias': _n(s, 'carreras_limpias'),
          'hits': _n(s, 'hits_permitidos'),
          'ponches': _n(s, 'ponches'),
          'bb': _n(s, 'bases_por_bolas'),
        },
      ),
    );
    if (v == null) return;
    await DatabaseHelper.instance.actualizarSalidaLanzador(
      s['id'] as int,
      outs: v['outs']!,
      picheos: v['picheos']!,
      carrerasPermitidas: v['carreras']!,
      carrerasLimpias: v['limpias']!,
      hitsPermitidos: v['hits']!,
      ponches: v['ponches']!,
      basesPorBolas: v['bb']!,
    );
    await _cargar();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF2F4F7),
      appBar: AppBar(
        backgroundColor: _colorFondoOscuro,
        foregroundColor: Colors.white,
        title: const Text('HISTORIAL DE SALIDAS'),
      ),
      body: _cargando
          ? const Center(child: CircularProgressIndicator())
          : _salidas.isEmpty
              ? const Center(
                  child: Text('Sin salidas registradas todavia.', style: TextStyle(color: Colors.black54)),
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: _salidas.length + 1,
                  itemBuilder: (ctx, i) {
                    if (i == 0) {
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 8, left: 4),
                        child: Text(
                          '${widget.nombreLanzador} - ${_salidas.length} salida(s)',
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                        ),
                      );
                    }
                    final s = _salidas[i - 1];
                    return Card(
                      child: ListTile(
                        title: Text(
                          '${_fechaVista(s['fecha'] as String)}   ${_ip(_outs(s))} IP${_resumenJuego(s)}',
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        subtitle: Text(
                          'H ${_n(s, 'hits_permitidos')} | R ${_n(s, 'carreras_permitidas')} | '
                          'CL ${_n(s, 'carreras_limpias')} | K ${_n(s, 'ponches')} | '
                          'BB ${_n(s, 'bases_por_bolas')} | P ${_n(s, 'picheos_lanzados')}',
                          style: const TextStyle(fontSize: 12),
                        ),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              icon: const Icon(Icons.edit, color: _colorAcento),
                              onPressed: () => _editar(s),
                            ),
                            IconButton(
                              icon: const Icon(Icons.delete, color: Colors.redAccent),
                              onPressed: () => _borrar(s),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}

class _EditarSalidaDialog extends StatefulWidget {
  final String titulo;
  final String inningsInicial;
  final Map<String, int> inicial;

  const _EditarSalidaDialog({
    required this.titulo,
    required this.inningsInicial,
    required this.inicial,
  });

  @override
  State<_EditarSalidaDialog> createState() => _EditarSalidaDialogState();
}

class _EditarSalidaDialogState extends State<_EditarSalidaDialog> {
  static const List<List<String>> _campos = [
    ['picheos', 'Picheos lanzados'],
    ['carreras', 'Carreras permitidas'],
    ['limpias', 'Carreras limpias'],
    ['hits', 'Hits permitidos'],
    ['ponches', 'Ponches (K)'],
    ['bb', 'Bases por bolas (BB)'],
  ];

  late final TextEditingController _innings =
      TextEditingController(text: widget.inningsInicial);
  late final Map<String, TextEditingController> _ctrl = {
    for (final c in _campos)
      c[0]: TextEditingController(text: (widget.inicial[c[0]] ?? 0).toString()),
  };
  String? _error;

  @override
  void dispose() {
    _innings.dispose();
    for (final c in _ctrl.values) {
      c.dispose();
    }
    super.dispose();
  }

  void _guardar() {
    final outs = outsDesdeInnings(_innings.text);
    if (outs == null) {
      setState(() => _error = 'Innings invalidos. Usa 6, 6.1 o 6.2.');
      return;
    }
    final v = <String, int>{'outs': outs};
    for (final c in _campos) {
      final txt = _ctrl[c[0]]!.text.trim();
      final n = txt.isEmpty ? 0 : int.tryParse(txt);
      if (n == null || n < 0) {
        setState(() => _error = '"${c[1]}" debe ser un entero mayor o igual a 0.');
        return;
      }
      v[c[0]] = n;
    }
    if (v['limpias']! > v['carreras']!) {
      setState(() => _error = 'Las carreras limpias no pueden superar las permitidas.');
      return;
    }
    Navigator.pop(context, v);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.titulo),
      content: SizedBox(
        width: double.maxFinite,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: TextField(
                  controller: _innings,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(
                    labelText: 'Innings (ej. 6.1)',
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                ),
              ),
              for (final c in _campos)
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: TextField(
                    controller: _ctrl[c[0]],
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: c[1],
                      border: const OutlineInputBorder(),
                      isDense: true,
                    ),
                  ),
                ),
              if (_error != null)
                Text(_error!, style: const TextStyle(color: Colors.redAccent, fontSize: 12)),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('CANCELAR')),
        TextButton(onPressed: _guardar, child: const Text('GUARDAR')),
      ],
    );
  }
}
