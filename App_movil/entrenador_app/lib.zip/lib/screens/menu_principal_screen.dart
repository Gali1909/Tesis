import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'equipos_screen.dart';
import 'jugadores_libres_screen.dart';
import 'juego_vivo_inicio_screen.dart';
import 'lineups_screen.dart';
import 'analisis_screen.dart';
import 'record_juegos_screen.dart';
import 'roster_screen.dart';
import '../services/database_helper.dart';
import '../models/equipo.dart';

const Color _fondo = Color(0xFF14171C);
const Color _superficie = Color(0xFF1E232B);
const Color _cian = Color(0xFF0ABDCF);
const Color _ambar = Color(0xFFFFB703);
const Color _rojo = Color(0xFFE63946);
const Color _textoSuave = Color(0xFF9AA4B2);

/// Dibuja un diamante de beisbol tenue como fondo del encabezado.
class _CampoPainter extends CustomPainter {
  const _CampoPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final linea = Paint()
      ..color = const Color(0x2E0ABDCF)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;
    final relleno = Paint()..color = const Color(0x400ABDCF);

    final centro = Offset(size.width * 0.88, size.height * 0.62);
    final r = size.height * 0.95;

    Path rombo(double radio) => Path()
      ..moveTo(centro.dx, centro.dy - radio)
      ..lineTo(centro.dx + radio, centro.dy)
      ..lineTo(centro.dx, centro.dy + radio)
      ..lineTo(centro.dx - radio, centro.dy)
      ..close();

    canvas.drawPath(rombo(r), linea);
    canvas.drawPath(rombo(r * 0.55), linea);
    canvas.drawCircle(centro, r * 0.14, linea);

    final bases = [
      Offset(centro.dx, centro.dy - r),
      Offset(centro.dx + r, centro.dy),
      Offset(centro.dx - r, centro.dy),
      Offset(centro.dx, centro.dy + r),
    ];
    for (final p in bases) {
      canvas.save();
      canvas.translate(p.dx, p.dy);
      canvas.rotate(0.785398);
      canvas.drawRect(
        Rect.fromCenter(center: Offset.zero, width: 14, height: 14),
        relleno,
      );
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

/// Linea con puntadas rojas, como la costura de una pelota.
class _CosturaPainter extends CustomPainter {
  const _CosturaPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final base = Paint()
      ..color = const Color(0x33E63946)
      ..strokeWidth = 1.5;
    final puntada = Paint()
      ..color = _rojo
      ..strokeWidth = 2
      ..strokeCap = StrokeCap.round;
    final mitad = size.height / 2;
    canvas.drawLine(Offset(0, mitad), Offset(size.width, mitad), base);
    for (double x = 6; x < size.width - 10; x += 14) {
      canvas.drawLine(Offset(x, 1), Offset(x + 6, size.height - 1), puntada);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

final ValueNotifier<int> _refrescoRecord = ValueNotifier<int>(0);

/// Etiqueta con el record G - P de la temporada actual en el encabezado.
class _RecordChip extends StatefulWidget {
  final int anio;

  const _RecordChip({required this.anio});

  @override
  State<_RecordChip> createState() => _RecordChipState();
}

class _RecordChipState extends State<_RecordChip> {
  Map<String, int>? _record;

  @override
  void initState() {
    super.initState();
    _refrescoRecord.addListener(_cargar);
    _cargar();
  }

  @override
  void dispose() {
    _refrescoRecord.removeListener(_cargar);
    super.dispose();
  }

  Future<void> _cargar() async {
    final r = await DatabaseHelper.instance.recordEquipo(anio: widget.anio);
    if (!mounted) return;
    setState(() => _record = r);
  }

  @override
  Widget build(BuildContext context) {
    final r = _record;
    String texto = '-- G - -- P';
    if (r != null) {
      final g = r['g'] ?? 0;
      final p = r['p'] ?? 0;
      final e = r['e'] ?? 0;
      texto = e > 0 ? '$g G - $p P - $e E' : '$g G - $p P';
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _cian),
        color: const Color(0x1F0ABDCF),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.emoji_events, color: _cian, size: 14),
          const SizedBox(width: 6),
          Text(
            texto,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 11,
              fontWeight: FontWeight.bold,
              letterSpacing: 2,
            ),
          ),
        ],
      ),
    );
  }
}

class MenuPrincipalScreen extends StatelessWidget {
  final int equipoId;
  final String nombreEquipo;
  final ValueChanged<String>? onNombreCambiado;

  const MenuPrincipalScreen({
    super.key,
    required this.equipoId,
    required this.nombreEquipo,
    this.onNombreCambiado,
  });

  Future<void> _renombrar(BuildContext context) async {
    final controller = TextEditingController(text: nombreEquipo);
    final nuevo = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Nombre del equipo'),
        content: TextField(
          controller: controller,
          autofocus: true,
          maxLength: 40,
          textCapitalization: TextCapitalization.words,
          decoration: const InputDecoration(border: OutlineInputBorder()),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('CANCELAR'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, controller.text.trim()),
            child: const Text('GUARDAR'),
          ),
        ],
      ),
    );
    if (nuevo == null || nuevo.isEmpty || nuevo == nombreEquipo) return;
    await DatabaseHelper.instance.actualizarEquipo(
      Equipo(equipoId: equipoId, nombre: nuevo, tipo: 'propio'),
    );
    onNombreCambiado?.call(nuevo);
  }

  Widget _encabezado(BuildContext context) {
    final arriba = MediaQuery.of(context).padding.top;
    final anio = DateTime.now().year;
    return ClipRect(
      child: Stack(
        children: [
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF0E3A44), _fondo],
                ),
              ),
              child: const CustomPaint(painter: _CampoPainter()),
            ),
          ),
          Padding(
            padding: EdgeInsets.fromLTRB(24, arriba + 28, 24, 30),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 64,
                      height: 64,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: const Color(0x260ABDCF),
                        border: Border.all(color: _cian, width: 2),
                      ),
                      child: const Icon(Icons.sports_baseball,
                          color: _cian, size: 34),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'ENTRENADOR',
                            style: TextStyle(
                              color: _cian,
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 3,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              Flexible(
                                child: Text(
                                  nombreEquipo,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 30,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              IconButton(
                                icon: const Icon(Icons.edit,
                                    color: _textoSuave, size: 18),
                                tooltip: 'Cambiar nombre del equipo',
                                visualDensity: VisualDensity.compact,
                                onPressed: () => _renombrar(context),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: _rojo),
                    color: const Color(0x1FE63946),
                  ),
                  child: Text(
                    'TEMPORADA $anio',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 2,
                    ),
                  ),
                ),
                _RecordChip(anio: anio),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _tarjeta(
    BuildContext context, {
    required int indice,
    required IconData icono,
    required String titulo,
    required String subtitulo,
    required Color color,
    required Widget destino,
  }) {
    final numero = '0${indice + 1}';
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.0, end: 1.0),
      duration: Duration(milliseconds: 450 + indice * 150),
      curve: Curves.easeOutCubic,
      builder: (context, v, child) => Opacity(
        opacity: v,
        child: Transform.translate(offset: Offset(0, 26 * (1 - v)), child: child),
      ),
      child: Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(20),
            onTap: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => destino),
              );
              _refrescoRecord.value++;
            },
            child: Ink(
              decoration: BoxDecoration(
                color: _superficie,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: color.withAlpha(80)),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: Stack(
                  children: [
                    Positioned(
                      right: 16,
                      bottom: -12,
                      child: Text(
                        numero,
                        style: TextStyle(
                          fontSize: 76,
                          height: 1,
                          fontWeight: FontWeight.w900,
                          color: color.withAlpha(30),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 0,
                      top: 0,
                      bottom: 0,
                      child: Container(width: 5, color: color),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(20, 16, 16, 16),
                      child: Row(
                        children: [
                          Container(
                            width: 56,
                            height: 56,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(16),
                              gradient: LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [
                                  color,
                                  Color.lerp(color, Colors.black, 0.3)!,
                                ],
                              ),
                            ),
                            child: Icon(icono, color: Colors.white, size: 28),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  titulo,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 17,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  subtitulo,
                                  style: const TextStyle(
                                    color: _textoSuave,
                                    fontSize: 13,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const Icon(Icons.arrow_forward_ios_rounded,
                              color: Color(0xFF5B6675), size: 16),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light,
      child: Scaffold(
        backgroundColor: _fondo,
        body: ListView(
          padding: EdgeInsets.zero,
          children: [
            _encabezado(context),
            const Padding(
              padding: EdgeInsets.fromLTRB(24, 0, 24, 0),
              child: SizedBox(
                height: 12,
                child: CustomPaint(
                  painter: _CosturaPainter(),
                  size: Size.infinite,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Padding(
                    padding: EdgeInsets.only(left: 4, bottom: 16),
                    child: Text(
                      'Que quieres hacer hoy?',
                      style: TextStyle(color: _textoSuave, fontSize: 15),
                    ),
                  ),
                  _tarjeta(
                    context,
                    indice: 0,
                    icono: Icons.groups,
                    titulo: 'Roster',
                    subtitulo: 'Jugadores de tu equipo',
                    color: _cian,
                    destino: RosterScreen(
                      equipoId: equipoId,
                      nombreEquipo: nombreEquipo,
                    ),
                  ),
                  _tarjeta(
                    context,
                    indice: 1,
                    icono: Icons.sports_baseball,
                    titulo: 'Equipos y rivales',
                    subtitulo: 'Crear rivales y ver sus jugadores',
                    color: _ambar,
                    destino: const EquiposScreen(),
                  ),
                  _tarjeta(
                    context,
                    indice: 2,
                    icono: Icons.emoji_events,
                    titulo: 'Record y juegos',
                    subtitulo: 'Ganados, perdidos y marcadores',
                    color: _rojo,
                    destino: const RecordJuegosScreen(),
                  ),
                  _tarjeta(
                    context,
                    indice: 3,
                    icono: Icons.person_search,
                    titulo: 'Jugadores libres',
                    subtitulo: 'Jugadores dejados en libertad',
                    color: const Color(0xFF3DDC84),
                    destino: JugadoresLibresScreen(
                      equipoId: equipoId,
                      nombreEquipo: nombreEquipo,
                    ),
                  ),
                  _tarjeta(
                    context,
                    indice: 4,
                    icono: Icons.play_circle_fill,
                    titulo: 'Juego en vivo',
                    subtitulo: 'Registra el juego mientras se juega',
                    color: const Color(0xFFB388FF),
                    destino: const JuegoVivoInicioScreen(),
                  ),
                  _tarjeta(
                    context,
                    indice: 5,
                    icono: Icons.format_list_numbered,
                    titulo: 'Lineups',
                    subtitulo: 'Arma y guarda tus alineaciones',
                    color: const Color(0xFFFFB74D),
                    destino: const LineupsScreen(),
                  ),
                  _tarjeta(
                    context,
                    indice: 6,
                    icono: Icons.insights,
                    titulo: 'Analisis',
                    subtitulo: 'Pitcheos, bateadores y cuentas por juego',
                    color: const Color(0xFF81C784),
                    destino: const AnalisisScreen(),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
