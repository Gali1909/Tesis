import 'package:sqflite/sqflite.dart';

import 'database_helper.dart';
import 'corredores_db.dart';
import 'juego_lineup_db.dart';

const Set<String> _resultadosOut = {
  'ponche',
  'out_roletazo',
  'out_elevado',
  'out_linea',
};

/// Tablas de turnos al bate y lanzamientos. Se puede llamar varias veces.
Future<void> crearTablasTurnos(DatabaseExecutor db) async {
  await db.execute('''
    CREATE TABLE IF NOT EXISTS turno_bate (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      juego_id INTEGER NOT NULL,
      numero INTEGER NOT NULL,
      entrada INTEGER NOT NULL,
      mitad TEXT NOT NULL,
      propio INTEGER NOT NULL,
      orden INTEGER,
      bateador_id INTEGER NOT NULL,
      lanzador_id INTEGER,
      bolas INTEGER NOT NULL DEFAULT 0,
      strikes INTEGER NOT NULL DEFAULT 0,
      resultado TEXT,
      creado_ms INTEGER NOT NULL,
      uuid TEXT,
      UNIQUE (juego_id, numero),
      FOREIGN KEY (juego_id) REFERENCES juego (juego_id) ON DELETE CASCADE
    )
  ''');
  await db.execute('''
    CREATE TABLE IF NOT EXISTS lanzamiento (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      turno_id INTEGER NOT NULL,
      juego_id INTEGER NOT NULL,
      numero INTEGER NOT NULL,
      tipo_lanzamiento_id INTEGER,
      resultado TEXT NOT NULL,
      bolas_antes INTEGER NOT NULL DEFAULT 0,
      strikes_antes INTEGER NOT NULL DEFAULT 0,
      creado_ms INTEGER NOT NULL,
      uuid TEXT,
      UNIQUE (turno_id, numero),
      FOREIGN KEY (turno_id) REFERENCES turno_bate (id) ON DELETE CASCADE,
      FOREIGN KEY (juego_id) REFERENCES juego (juego_id) ON DELETE CASCADE
    )
  ''');
  await db.execute('''
    CREATE TABLE IF NOT EXISTS juego_lineup_rival (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      juego_id INTEGER NOT NULL,
      orden INTEGER NOT NULL,
      jugador_id INTEGER NOT NULL,
      uuid TEXT,
      UNIQUE (juego_id, orden),
      FOREIGN KEY (juego_id) REFERENCES juego (juego_id) ON DELETE CASCADE
    )
  ''');
}

Future<Map<String, dynamic>> _juegoEnCursoTurno(
  DatabaseExecutor txn,
  int juegoId,
) async {
  final r = await txn.query(
    'juego',
    columns: [
      'estado',
      'entrada_actual',
      'mitad_actual',
      'outs_actuales',
      'propio_local',
      'lanzador_inicial_id',
      'lanzador_propio_id',
      'lanzador_rival_id',
      'equipo_rival_id',
    ],
    where: 'juego_id = ?',
    whereArgs: [juegoId],
    limit: 1,
  );
  if (r.isEmpty) throw StateError('El juego ya no existe.');
  if (r.first['estado'] != 'en_juego') throw StateError('Este juego ya termino.');
  return r.first;
}

bool _bateaPropioTurno(bool local, String mitad) =>
    (local && mitad == 'baja') || (!local && mitad == 'alta');

Future<void> _fijarEstadoTurno(
  DatabaseExecutor txn,
  int juegoId,
  int entrada,
  String mitad,
  int outs,
) async {
  await txn.update(
    'juego',
    {
      'entrada_actual': entrada,
      'mitad_actual': mitad,
      'outs_actuales': outs,
    },
    where: 'juego_id = ?',
    whereArgs: [juegoId],
  );
}

Map<String, int> _contarCuenta(List<Map<String, dynamic>> lanzamientos) {
  var bolas = 0;
  var strikes = 0;
  for (final p in lanzamientos) {
    final r = p['resultado'] as String;
    if (r == 'bola') {
      bolas++;
    } else if (r == 'strike_cantado' || r == 'strike_swing') {
      strikes++;
    } else if (r == 'foul') {
      if (strikes < 2) strikes++;
    }
  }
  return {'bolas': bolas, 'strikes': strikes};
}

/// Cierra el turno con su resultado. Si es out, suma el out de la mitad y
/// guarda la accion para poder deshacerlo.
Future<void> _cerrarTurno(
  DatabaseExecutor txn,
  int juegoId,
  int turnoId,
  String resultado,
) async {
  await txn.update(
    'turno_bate',
    {'resultado': resultado},
    where: 'id = ?',
    whereArgs: [turnoId],
  );
  if (!_resultadosOut.contains(resultado)) {
    await prepararCorredoresTurno(txn, juegoId, turnoId, resultado, terminoMitad: false);
    return;
  }

  final j = await _juegoEnCursoTurno(txn, juegoId);
  final entrada = (j['entrada_actual'] as int?) ?? 1;
  final mitad = (j['mitad_actual'] as String?) ?? 'alta';
  final outs = (j['outs_actuales'] as int?) ?? 0;

  await txn.insert('juego_accion', {
    'juego_id': juegoId,
    'tipo': 'out_turno',
    'equipo': null,
    'delta': 0,
    'entrada_antes': entrada,
    'mitad_antes': mitad,
    'outs_antes': outs,
    'ref_id': turnoId,
    'creado_ms': DateTime.now().millisecondsSinceEpoch,
  });

  final nuevos = outs + 1;
  if (nuevos >= 3) {
    if (mitad == 'alta') {
      await _fijarEstadoTurno(txn, juegoId, entrada, 'baja', 0);
    } else {
      await txn.rawInsert(
        'INSERT OR IGNORE INTO juego_entrada '
        '(juego_id, numero, carreras_propias, carreras_rival) VALUES (?, ?, 0, 0)',
        [juegoId, entrada + 1],
      );
      await _fijarEstadoTurno(txn, juegoId, entrada + 1, 'alta', 0);
    }
  } else {
    await _fijarEstadoTurno(txn, juegoId, entrada, mitad, nuevos);
  }
  await prepararCorredoresTurno(txn, juegoId, turnoId, resultado, terminoMitad: nuevos >= 3);
}

extension TurnoDB on DatabaseHelper {
  Future<List<Map<String, dynamic>>> obtenerTiposPitcheo() async {
    final db = await database;
    return db.query('tipo_lanzamiento', orderBy: 'nombre COLLATE NOCASE');
  }

    /// Tipos de pitcheo registrados al lanzador. Si no hay lanzador
  /// identificado (null), devuelve todos los tipos.
  Future<List<Map<String, dynamic>>> obtenerTiposPitcheoLanzador(
    int? lanzadorId,
  ) async {
    if (lanzadorId == null) return obtenerTiposPitcheo();
    final db = await database;
    return db.rawQuery('''
      SELECT DISTINCT t.tipo_lanzamiento_id, t.nombre
      FROM lanzador_tipo_picheo lp
      JOIN tipo_lanzamiento t
        ON t.tipo_lanzamiento_id = lp.tipo_lanzamiento_id
      WHERE lp.lanzador_id = ?
      ORDER BY t.nombre COLLATE NOCASE
    ''', [lanzadorId]);
  }
Future<int?> ultimoTipoPitcheo(int juegoId) async {
    final db = await database;
    final r = await db.rawQuery(
      'SELECT tipo_lanzamiento_id AS t FROM lanzamiento '
      'WHERE juego_id = ? AND tipo_lanzamiento_id IS NOT NULL '
      'ORDER BY id DESC LIMIT 1',
      [juegoId],
    );
    return r.isEmpty ? null : r.first['t'] as int?;
  }

  /// Turno que esta en curso (sin resultado), o null.
  Future<Map<String, dynamic>?> obtenerTurnoAbierto(int juegoId) async {
    final db = await database;
    final r = await db.rawQuery('''
      SELECT t.*, b.nombre AS bateador_nombre, b.numero AS bateador_numero,
             p.nombre AS lanzador_nombre
      FROM turno_bate t
      LEFT JOIN jugador b ON b.jugador_id = t.bateador_id
      LEFT JOIN jugador p ON p.jugador_id = t.lanzador_id
      WHERE t.juego_id = ? AND t.resultado IS NULL
      ORDER BY t.id DESC
      LIMIT 1
    ''', [juegoId]);
    return r.isEmpty ? null : r.first;
  }

  Future<List<Map<String, dynamic>>> obtenerLanzamientosTurno(int turnoId) async {
    final db = await database;
    return db.rawQuery('''
      SELECT l.numero, l.resultado, t.nombre AS tipo
      FROM lanzamiento l
      LEFT JOIN tipo_lanzamiento t
        ON t.tipo_lanzamiento_id = l.tipo_lanzamiento_id
      WHERE l.turno_id = ?
      ORDER BY l.numero
    ''', [turnoId]);
  }

  /// Quien batea despues segun el lineup. Si es el rival y todavia falta
  /// agregar un bateador, devuelve nuevo = true.
  Future<Map<String, dynamic>> siguienteBateadorTurno(int juegoId) async {
    final db = await database;
    final j = await _juegoEnCursoTurno(db, juegoId);
    final local = ((j['propio_local'] as int?) ?? 0) == 1;
    final mitad = (j['mitad_actual'] as String?) ?? 'alta';
    final propio = _bateaPropioTurno(local, mitad);

    final c = await db.rawQuery(
      'SELECT COUNT(*) AS n FROM turno_bate '
      'WHERE juego_id = ? AND propio = ? AND resultado IS NOT NULL',
      [juegoId, propio ? 1 : 0],
    );
    final n = (c.first['n'] as num?)?.toInt() ?? 0;

    List<Map<String, dynamic>> lineup;
    if (propio) {
      lineup = await obtenerLineupJuego(juegoId);
      if (lineup.isEmpty) {
        throw StateError('Falta la alineacion de tu equipo en este juego.');
      }
    } else {
      lineup = await db.rawQuery('''
        SELECT l.orden, l.jugador_id, j.nombre, j.numero
        FROM juego_lineup_rival l
        JOIN jugador j ON j.jugador_id = l.jugador_id
        WHERE l.juego_id = ?
        ORDER BY l.orden
      ''', [juegoId]);
      if (lineup.isEmpty || (lineup.length < 9 && n >= lineup.length)) {
        return {'propio': false, 'nuevo': true, 'orden': lineup.length + 1};
      }
    }
    final idx = n % lineup.length;
    final f = lineup[idx];
    return {
      'propio': propio,
      'nuevo': false,
      'orden': idx + 1,
      'jugador_id': f['jugador_id'],
      'nombre': f['nombre'],
      'numero': f['numero'],
    };
  }

  /// Crea un bateador del equipo rival y lo agrega al final de su lineup.
  Future<int> agregarBateadorRival(
    int juegoId,
    String nombre,
    int? numero,
  ) async {
    final db = await database;
    return db.transaction<int>((txn) async {
      final j = await _juegoEnCursoTurno(txn, juegoId);
      final rivalId = j['equipo_rival_id'] as int?;
      if (rivalId == null) {
        throw StateError(
          'Este juego no tiene rival. Asignalo en Record y juegos para registrar sus turnos.',
        );
      }
      final id = await txn.insert('jugador', {
        'equipo_id': rivalId,
        'nombre': nombre,
        'rol': 'bateador',
        'numero': numero,
      });
      final m = await txn.rawQuery(
        'SELECT COALESCE(MAX(orden), 0) AS m FROM juego_lineup_rival WHERE juego_id = ?',
        [juegoId],
      );
      final orden = ((m.first['m'] as num?)?.toInt() ?? 0) + 1;
      await txn.insert('juego_lineup_rival', {
        'juego_id': juegoId,
        'orden': orden,
        'jugador_id': id,
      });
      return id;
    });
  }

  Future<int> iniciarTurno(
    int juegoId, {
    required int bateadorId,
    required int orden,
  }) async {
    final db = await database;
    return db.transaction<int>((txn) async {
      final j = await _juegoEnCursoTurno(txn, juegoId);
      await exigirCorredoresResueltos(txn, juegoId);
      final abierto = await txn.query(
        'turno_bate',
        columns: ['id'],
        where: 'juego_id = ? AND resultado IS NULL',
        whereArgs: [juegoId],
        limit: 1,
      );
      if (abierto.isNotEmpty) return abierto.first['id'] as int;

      final local = ((j['propio_local'] as int?) ?? 0) == 1;
      final mitad = (j['mitad_actual'] as String?) ?? 'alta';
      final propio = _bateaPropioTurno(local, mitad);
      final m = await txn.rawQuery(
        'SELECT COALESCE(MAX(numero), 0) AS m FROM turno_bate WHERE juego_id = ?',
        [juegoId],
      );
      final numero = ((m.first['m'] as num?)?.toInt() ?? 0) + 1;
      return txn.insert('turno_bate', {
        'juego_id': juegoId,
        'numero': numero,
        'entrada': (j['entrada_actual'] as int?) ?? 1,
        'mitad': mitad,
        'propio': propio ? 1 : 0,
        'orden': orden,
        'bateador_id': bateadorId,
        'lanzador_id': propio ? j['lanzador_rival_id'] : (j['lanzador_propio_id'] ?? j['lanzador_inicial_id']),
        'creado_ms': DateTime.now().millisecondsSinceEpoch,
      });
    });
  }

  /// Registra un lanzamiento. resultado: bola, strike_cantado, strike_swing,
  /// foul, en_juego o golpeado. Para en_juego y golpeado hay que pasar
  /// resultadoTurno. Devuelve el resultado del turno si este lanzamiento
  /// lo cerro (boleto, ponche, hit, out...), o null si sigue abierto.
  Future<String?> registrarLanzamientoTurno(
    int juegoId,
    int turnoId,
    String resultado, {
    String? resultadoTurno,
    int? tipoId,
    double? zonaX,
    double? zonaY,
  }) async {
    if ((resultado == 'en_juego' || resultado == 'golpeado') &&
        resultadoTurno == null) {
      throw StateError('Falta el resultado del turno.');
    }
    final db = await database;
    return db.transaction<String?>((txn) async {
      await _juegoEnCursoTurno(txn, juegoId);
      final t = await txn.query(
        'turno_bate',
        where: 'id = ? AND juego_id = ? AND resultado IS NULL',
        whereArgs: [turnoId, juegoId],
        limit: 1,
      );
      if (t.isEmpty) throw StateError('Este turno ya esta cerrado.');
      var bolas = (t.first['bolas'] as int?) ?? 0;
      var strikes = (t.first['strikes'] as int?) ?? 0;

      final m = await txn.rawQuery(
        'SELECT COALESCE(MAX(numero), 0) AS m FROM lanzamiento WHERE turno_id = ?',
        [turnoId],
      );
      final numero = ((m.first['m'] as num?)?.toInt() ?? 0) + 1;
      await txn.insert('lanzamiento', {
        'turno_id': turnoId,
        'juego_id': juegoId,
        'numero': numero,
        'tipo_lanzamiento_id': tipoId,
        'zona_x': zonaX,
        'zona_y': zonaY,
        'resultado': resultado,
        'bolas_antes': bolas,
        'strikes_antes': strikes,
        'creado_ms': DateTime.now().millisecondsSinceEpoch,
      });

      String? cierre = resultadoTurno;
      if (resultado == 'bola') {
        bolas++;
        if (bolas >= 4) cierre = 'boleto';
      } else if (resultado == 'strike_cantado' || resultado == 'strike_swing') {
        strikes++;
        if (strikes >= 3) cierre = 'ponche';
      } else if (resultado == 'foul') {
        if (strikes < 2) strikes++;
      }
      await txn.update(
        'turno_bate',
        {'bolas': bolas, 'strikes': strikes},
        where: 'id = ?',
        whereArgs: [turnoId],
      );
      if (cierre != null) {
        await _cerrarTurno(txn, juegoId, turnoId, cierre);
      }
      return cierre;
    });
  }

  /// Quita el ultimo lanzamiento del juego. Si cerro el turno, lo reabre
  /// y revierte el out. Devuelve false si no habia nada que deshacer.
  Future<bool> deshacerLanzamientoTurno(int juegoId) async {
    final db = await database;
    return db.transaction<bool>((txn) async {
      await _juegoEnCursoTurno(txn, juegoId);
      final u = await txn.query(
        'lanzamiento',
        where: 'juego_id = ?',
        whereArgs: [juegoId],
        orderBy: 'id DESC',
        limit: 1,
      );
      if (u.isEmpty) return false;
      final pitchId = u.first['id'] as int;
      final jNueva = await txn.rawQuery(
        'SELECT COUNT(*) AS n FROM jugada_corredor WHERE juego_id = ? AND creado_ms > ?',
        [juegoId, u.first['creado_ms']],
      );
      if (((jNueva.first['n'] as num?)?.toInt() ?? 0) > 0) {
        throw StateError(
          'Antes deshaz con DESHACER JUGADA la jugada de corredores posterior a ese lanzamiento.',
        );
      }
      final turnoId = u.first['turno_id'] as int;

      final t = await txn.query(
        'turno_bate',
        where: 'id = ?',
        whereArgs: [turnoId],
        limit: 1,
      );
      final cerrado = t.isNotEmpty && t.first['resultado'] != null;
      if (cerrado) {
        await revertirCorredoresTurno(txn, juegoId, t.first);
        final acc = await txn.query(
          'juego_accion',
          where: "juego_id = ? AND tipo = 'out_turno' AND ref_id = ?",
          whereArgs: [juegoId, turnoId],
          limit: 1,
        );
        if (acc.isNotEmpty) {
          final ultima = await txn.query(
            'juego_accion',
            where: 'juego_id = ?',
            whereArgs: [juegoId],
            orderBy: 'id DESC',
            limit: 1,
          );
          if (ultima.first['id'] != acc.first['id']) {
            throw StateError(
              'Antes deshaz con DESHACER las acciones posteriores del marcador.',
            );
          }
          await _fijarEstadoTurno(
            txn,
            juegoId,
            acc.first['entrada_antes'] as int,
            acc.first['mitad_antes'] as String,
            acc.first['outs_antes'] as int,
          );
          await txn.delete(
            'juego_accion',
            where: 'id = ?',
            whereArgs: [acc.first['id']],
          );
        }
        // Un turno vacio que se abrio despues del cierre ya no aplica.
        await txn.delete(
          'turno_bate',
          where: 'juego_id = ? AND id > ? AND resultado IS NULL',
          whereArgs: [juegoId, turnoId],
        );
      }

      await txn.delete('lanzamiento', where: 'id = ?', whereArgs: [pitchId]);
      final restantes = await txn.query(
        'lanzamiento',
        where: 'turno_id = ?',
        whereArgs: [turnoId],
        orderBy: 'numero',
      );
      if (restantes.isEmpty) {
        await txn.delete('turno_bate', where: 'id = ?', whereArgs: [turnoId]);
      } else {
        final c = _contarCuenta(restantes);
        await txn.update(
          'turno_bate',
          {'bolas': c['bolas'], 'strikes': c['strikes'], 'resultado': null},
          where: 'id = ?',
          whereArgs: [turnoId],
        );
      }
      return true;
    });
  }
}