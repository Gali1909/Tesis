import 'package:sqflite/sqflite.dart';

import 'database_helper.dart';
import 'estadisticas_juego_db.dart';

class _EstadoVivo {
  final int entrada;
  final String mitad;
  final int outs;
  final bool local;

  const _EstadoVivo(this.entrada, this.mitad, this.outs, this.local);
}

/// Quien batea en la mitad actual: el equipo propio batea en la baja si es
/// local, y en la alta si es visitante.
bool _bateaPropioVivo(bool local, String mitad) =>
    (local && mitad == 'baja') || (!local && mitad == 'alta');

/// Agrega las columnas del estado en vivo a juego y la tabla juego_accion
/// (registro para deshacer). Se puede llamar varias veces sin problema.
Future<void> crearTablasJuegoVivo(DatabaseExecutor db) async {
  final cols = await db.rawQuery('PRAGMA table_info(juego)');
  final existentes = cols.map((c) => c['name'] as String).toSet();
  const nuevas = {
    'estado': 'TEXT',
    'propio_local': 'INTEGER',
    'entrada_actual': 'INTEGER',
    'mitad_actual': 'TEXT',
    'outs_actuales': 'INTEGER',
  };
  for (final e in nuevas.entries) {
    if (!existentes.contains(e.key)) {
      await db.execute('ALTER TABLE juego ADD COLUMN ${e.key} ${e.value}');
    }
  }

  await db.execute('''
    CREATE TABLE IF NOT EXISTS juego_accion (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      juego_id INTEGER NOT NULL,
      tipo TEXT NOT NULL,
      equipo TEXT,
      delta INTEGER NOT NULL DEFAULT 0,
      entrada_antes INTEGER NOT NULL,
      mitad_antes TEXT NOT NULL,
      outs_antes INTEGER NOT NULL,
      ref_id INTEGER,
      creado_ms INTEGER NOT NULL,
      FOREIGN KEY (juego_id) REFERENCES juego (juego_id) ON DELETE CASCADE
    )
  ''');
}

Future<_EstadoVivo> _leerEstadoVivo(DatabaseExecutor txn, int juegoId) async {
  final r = await txn.query(
    'juego',
    columns: [
      'estado',
      'entrada_actual',
      'mitad_actual',
      'outs_actuales',
      'propio_local',
    ],
    where: 'juego_id = ?',
    whereArgs: [juegoId],
    limit: 1,
  );
  if (r.isEmpty) throw StateError('El juego ya no existe.');
  final m = r.first;
  if (m['estado'] != 'en_juego') throw StateError('Este juego ya termino.');
  return _EstadoVivo(
    (m['entrada_actual'] as int?) ?? 1,
    (m['mitad_actual'] as String?) ?? 'alta',
    (m['outs_actuales'] as int?) ?? 0,
    ((m['propio_local'] as int?) ?? 0) == 1,
  );
}

Future<void> _guardarEstadoVivo(
  DatabaseExecutor txn,
  int juegoId,
  int entrada,
  String mitad,
  int outs,
) async {
  await txn.update(
    'juego',
    {
      'entrada_actual': entrada,
      'mitad_actual': mitad,
      'outs_actuales': outs,
    },
    where: 'juego_id = ?',
    whereArgs: [juegoId],
  );
}

Future<void> _asegurarEntradaVivo(
  DatabaseExecutor txn,
  int juegoId,
  int numero,
) async {
  await txn.rawInsert(
    'INSERT OR IGNORE INTO juego_entrada '
    '(juego_id, numero, carreras_propias, carreras_rival) VALUES (?, ?, 0, 0)',
    [juegoId, numero],
  );
}

Future<void> _registrarAccionVivo(
  DatabaseExecutor txn,
  int juegoId,
  String tipo,
  _EstadoVivo antes, {
  String? equipo,
  int delta = 0,
}) async {
  await txn.insert('juego_accion', {
    'juego_id': juegoId,
    'tipo': tipo,
    'equipo': equipo,
    'delta': delta,
    'entrada_antes': antes.entrada,
    'mitad_antes': antes.mitad,
    'outs_antes': antes.outs,
    'creado_ms': DateTime.now().millisecondsSinceEpoch,
  });
}

Future<void> _avanzarMitadVivo(
  DatabaseExecutor txn,
  int juegoId,
  _EstadoVivo e,
) async {
  if (e.mitad == 'alta') {
    await _guardarEstadoVivo(txn, juegoId, e.entrada, 'baja', 0);
  } else {
    await _asegurarEntradaVivo(txn, juegoId, e.entrada + 1);
    await _guardarEstadoVivo(txn, juegoId, e.entrada + 1, 'alta', 0);
  }
}

extension JuegoVivoDB on DatabaseHelper {
  /// Juego que esta en curso (solo puede haber uno), o null.
  Future<Map<String, dynamic>?> obtenerJuegoEnCurso() async {
    final db = await database;
    final r = await db.query(
      'juego',
      where: "estado = 'en_juego'",
      orderBy: 'juego_id DESC',
      limit: 1,
    );
    return r.isEmpty ? null : r.first;
  }

  Future<Map<String, dynamic>?> obtenerJuegoVivo(int juegoId) async {
    final db = await database;
    final r = await db.rawQuery('''
      SELECT j.*, q.nombre AS rival_nombre
      FROM juego j
      LEFT JOIN equipo q ON q.equipo_id = j.equipo_rival_id
      WHERE j.juego_id = ?
    ''', [juegoId]);
    return r.isEmpty ? null : r.first;
  }

  Future<int> iniciarJuegoVivo({
    required String fecha,
    required int? rivalId,
    required bool propioLocal,
  }) async {
    final db = await database;
    return db.transaction<int>((txn) async {
      final id = await txn.insert('juego', {
        'fecha': fecha,
        'equipo_rival_id': rivalId,
        'estado': 'en_juego',
        'propio_local': propioLocal ? 1 : 0,
        'entrada_actual': 1,
        'mitad_actual': 'alta',
        'outs_actuales': 0,
      });
      await _asegurarEntradaVivo(txn, id, 1);
      return id;
    });
  }

  Future<void> sumarOutVivo(int juegoId) async {
    final db = await database;
    await db.transaction((txn) async {
      final e = await _leerEstadoVivo(txn, juegoId);
      await _registrarAccionVivo(txn, juegoId, 'out', e);
      final outs = e.outs + 1;
      if (outs >= 3) {
        await _avanzarMitadVivo(txn, juegoId, e);
      } else {
        await _guardarEstadoVivo(txn, juegoId, e.entrada, e.mitad, outs);
      }
    });
  }

  /// Suma (delta = 1) o resta (delta = -1) una carrera al equipo que batea.
  Future<void> sumarCarreraVivo(int juegoId, {int delta = 1}) async {
    final db = await database;
    await db.transaction((txn) async {
      final e = await _leerEstadoVivo(txn, juegoId);
      final propio = _bateaPropioVivo(e.local, e.mitad);
      final col = propio ? 'carreras_propias' : 'carreras_rival';
      await _asegurarEntradaVivo(txn, juegoId, e.entrada);
      if (delta < 0) {
        final r = await txn.query(
          'juego_entrada',
          columns: [col],
          where: 'juego_id = ? AND numero = ?',
          whereArgs: [juegoId, e.entrada],
          limit: 1,
        );
        final actual = r.isEmpty ? 0 : ((r.first[col] as int?) ?? 0);
        if (actual <= 0) return;
      }
      await txn.rawUpdate(
        'UPDATE juego_entrada SET $col = $col + ? '
        'WHERE juego_id = ? AND numero = ?',
        [delta, juegoId, e.entrada],
      );
      await _registrarAccionVivo(
        txn,
        juegoId,
        'carrera',
        e,
        equipo: propio ? 'propio' : 'rival',
        delta: delta,
      );
    });
  }

  Future<void> cambiarMitadVivo(int juegoId) async {
    final db = await database;
    await db.transaction((txn) async {
      final e = await _leerEstadoVivo(txn, juegoId);
      await _registrarAccionVivo(txn, juegoId, 'cambio_mitad', e);
      await _avanzarMitadVivo(txn, juegoId, e);
    });
  }

  /// Deshace la ultima accion. Devuelve false si no habia nada que deshacer.
  Future<bool> deshacerVivo(int juegoId) async {
    final db = await database;
    return db.transaction<bool>((txn) async {
      await _leerEstadoVivo(txn, juegoId);
      final r = await txn.query(
        'juego_accion',
        where: 'juego_id = ?',
        whereArgs: [juegoId],
        orderBy: 'id DESC',
        limit: 1,
      );
      if (r.isEmpty) return false;
      final a = r.first;
      final tipo = a['tipo'] as String;
      if (tipo == 'out_turno') {
        throw StateError(
          'Ese out vino de un turno al bate. Usa DESHACER LANZAMIENTO en la pantalla del turno.',
        );
      }
      if (tipo == 'jugada_corredor') {
        throw StateError(
          'Esa accion vino de una jugada de corredores. Usa DESHACER JUGADA en la pantalla del turno.',
        );
      }
      final entrada = a['entrada_antes'] as int;
      final mitad = a['mitad_antes'] as String;
      final outs = a['outs_antes'] as int;
      if (tipo == 'carrera') {
        final col = (a['equipo'] as String) == 'propio'
            ? 'carreras_propias'
            : 'carreras_rival';
        final delta = (a['delta'] as int?) ?? 0;
        await txn.rawUpdate(
          'UPDATE juego_entrada SET $col = MAX(0, $col - ?) '
          'WHERE juego_id = ? AND numero = ?',
          [delta, juegoId, entrada],
        );
      }
      await _guardarEstadoVivo(txn, juegoId, entrada, mitad, outs);
      await txn.delete('juego_accion', where: 'id = ?', whereArgs: [a['id']]);
      return true;
    });
  }

  /// Cierra el juego: guarda el marcador final como la suma de las entradas.
  Future<void> terminarJuegoVivo(int juegoId) async {
    final db = await database;
    await db.transaction((txn) async {
      final e = await _leerEstadoVivo(txn, juegoId);
      var ultima = (e.mitad == 'alta' && e.outs == 0) ? e.entrada - 1 : e.entrada;
      if (ultima < 1) ultima = 1;
      await txn.delete(
        'juego_entrada',
        where: 'juego_id = ? AND numero > ? '
            'AND carreras_propias = 0 AND carreras_rival = 0',
        whereArgs: [juegoId, ultima],
      );
      final s = await txn.rawQuery('''
        SELECT COALESCE(SUM(carreras_propias), 0) AS p,
               COALESCE(SUM(carreras_rival), 0) AS r
        FROM juego_entrada
        WHERE juego_id = ?
      ''', [juegoId]);
      await txn.update(
        'juego',
        {
          'carreras_propias': (s.first['p'] as num).toInt(),
          'carreras_rival': (s.first['r'] as num).toInt(),
          'estado': 'finalizado',
        },
        where: 'juego_id = ?',
        whereArgs: [juegoId],
      );
      await escribirEstadisticasJuego(txn, juegoId);
    });
  }

  /// Borra un juego en curso (por ejemplo, uno iniciado por error).
  Future<void> descartarJuegoVivo(int juegoId) async {
    final db = await database;
    await db.transaction((txn) async {
      await _leerEstadoVivo(txn, juegoId);
      await txn.delete('juego', where: 'juego_id = ?', whereArgs: [juegoId]);
    });
  }
}