import 'dart:convert';

import 'package:sqflite/sqflite.dart';

import 'database_helper.dart';

const Set<String> _outsBateador = {
  'ponche',
  'out_roletazo',
  'out_elevado',
  'out_linea',
};

const Set<String> _conImpulsada = {
  'sencillo',
  'doble',
  'triple',
  'home_run',
  'boleto',
  'golpeado',
  'out_roletazo',
  'out_elevado',
  'out_linea',
};

/// Columnas de corredores en turno_bate, la tabla turno_carrera y la
/// columna de carreras limpias por juego. Se puede llamar varias veces.
Future<void> crearTablasCorredores(DatabaseExecutor db) async {
  var cols = await db.rawQuery('PRAGMA table_info(turno_bate)');
  var existentes = cols.map((c) => c['name'] as String).toSet();
  const nuevas = {
    'bases_antes': 'TEXT',
    'bases_despues': 'TEXT',
    'carreras': 'INTEGER NOT NULL DEFAULT 0',
    'outs_corredores': 'INTEGER NOT NULL DEFAULT 0',
  };
  for (final e in nuevas.entries) {
    if (!existentes.contains(e.key)) {
      await db.execute('ALTER TABLE turno_bate ADD COLUMN ${e.key} ${e.value}');
    }
  }

  await db.execute('''
    CREATE TABLE IF NOT EXISTS turno_carrera (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      turno_id INTEGER NOT NULL,
      juego_id INTEGER NOT NULL,
      corredor_id INTEGER NOT NULL,
      impulsor_id INTEGER,
      lanzador_id INTEGER,
      limpia INTEGER NOT NULL DEFAULT 1,
      uuid TEXT,
      FOREIGN KEY (turno_id) REFERENCES turno_bate (id) ON DELETE CASCADE,
      FOREIGN KEY (juego_id) REFERENCES juego (juego_id) ON DELETE CASCADE
    )
  ''');

  cols = await db.rawQuery('PRAGMA table_info(estadistica_juego_lanzador)');
  existentes = cols.map((c) => c['name'] as String).toSet();
  if (!existentes.contains('carreras_limpias_juego')) {
    await db.execute(
      'ALTER TABLE estadistica_juego_lanzador ADD COLUMN carreras_limpias_juego INTEGER',
    );
  }
}

/// Cada base guarda [jugador_id, lanzador_responsable_id, limpia (1/0)].
List<List<int?>?> _parsearBases(String? s) {
  if (s == null) return <List<int?>?>[null, null, null];
  final l = jsonDecode(s) as List;
  return <List<int?>?>[
    for (var i = 0; i < 3; i++)
      (i < l.length && l[i] != null)
          ? (l[i] as List).map((e) => e as int?).toList()
          : null,
  ];
}

String _destinoBateador(String resultado) {
  switch (resultado) {
    case 'doble':
      return '2';
    case 'triple':
      return '3';
    case 'home_run':
      return 'anota';
    case 'sencillo':
    case 'boleto':
    case 'golpeado':
    case 'error':
      return '1';
    default:
      return 'out';
  }
}

Future<void> _fijarEstado(
  DatabaseExecutor txn,
  int juegoId,
  int entrada,
  String mitad,
  int outs,
) async {
  await txn.update(
    'juego',
    {'entrada_actual': entrada, 'mitad_actual': mitad, 'outs_actuales': outs},
    where: 'juego_id = ?',
    whereArgs: [juegoId],
  );
}

/// Bases al empezar el turno: las que dejo el ultimo turno resuelto de la
/// misma mitad de entrada.
Future<List<List<int?>?>> _basesVigentes(
  DatabaseExecutor txn,
  int juegoId,
  int entrada,
  String mitad,
  int antesDeTurno,
) async {
  final vacias = <List<int?>?>[null, null, null];
  final r = await txn.query(
    'turno_bate',
    columns: ['id', 'bases_despues', 'entrada', 'mitad'],
    where: 'juego_id = ? AND id < ? AND resultado IS NOT NULL '
        'AND bases_despues IS NOT NULL',
    whereArgs: [juegoId, antesDeTurno],
    orderBy: 'id DESC',
    limit: 1,
  );
  var refId = 0;
  var base = vacias;
  if (r.isNotEmpty) {
    refId = r.first['id'] as int;
    if (r.first['entrada'] == entrada && r.first['mitad'] == mitad) {
      base = _parsearBases(r.first['bases_despues'] as String?);
    }
  }
  final jg = await txn.query(
    'jugada_corredor',
    columns: ['bases_despues', 'entrada', 'mitad'],
    where: 'juego_id = ? AND ((turno_ref = ? AND cerrado = 1) '
        'OR (turno_ref > ? AND turno_ref <= ?))',
    whereArgs: [juegoId, refId, refId, antesDeTurno],
    orderBy: 'id DESC',
    limit: 1,
  );
  if (jg.isNotEmpty) {
    if (jg.first['entrada'] == entrada && jg.first['mitad'] == mitad) {
      return _parsearBases(jg.first['bases_despues'] as String?);
    }
    return vacias;
  }
  return base;
}

/// Bases vigentes (incluye robos y otras jugadas de corredores).
Future<List<List<int?>?>> basesActuales(
  DatabaseExecutor txn,
  int juegoId,
  int entrada,
  String mitad,
  int antesDeTurno,
) =>
    _basesVigentes(txn, juegoId, entrada, mitad, antesDeTurno);

/// Se llama al cerrar un turno. Guarda las bases de antes. Si no hay
/// corredores en base lo resuelve solo; si los hay, queda pendiente.
Future<void> prepararCorredoresTurno(
  DatabaseExecutor txn,
  int juegoId,
  int turnoId,
  String resultado, {
  required bool terminoMitad,
}) async {
  final t = await txn.query(
    'turno_bate',
    where: 'id = ?',
    whereArgs: [turnoId],
    limit: 1,
  );
  if (t.isEmpty) return;
  final entrada = t.first['entrada'] as int;
  final mitad = t.first['mitad'] as String;
  final antes = await _basesVigentes(txn, juegoId, entrada, mitad, turnoId);
  await txn.update(
    'turno_bate',
    {'bases_antes': jsonEncode(antes)},
    where: 'id = ?',
    whereArgs: [turnoId],
  );
  if (terminoMitad) {
    await txn.update(
      'turno_bate',
      {'bases_despues': jsonEncode(<List<int?>?>[null, null, null]), 'carreras': 0},
      where: 'id = ?',
      whereArgs: [turnoId],
    );
    return;
  }
  if (antes.every((b) => b == null)) {
    await _aplicarMovimientos(txn, juegoId, turnoId, [
      {'origen': 0, 'destino': _destinoBateador(resultado)},
    ]);
  }
}

Future<void> exigirCorredoresResueltos(DatabaseExecutor txn, int juegoId) async {
  final r = await txn.query(
    'turno_bate',
    columns: ['bases_antes', 'bases_despues'],
    where: 'juego_id = ? AND resultado IS NOT NULL',
    whereArgs: [juegoId],
    orderBy: 'id DESC',
    limit: 1,
  );
  if (r.isNotEmpty &&
      r.first['bases_antes'] != null &&
      r.first['bases_despues'] == null) {
    throw StateError(
      'Faltan los corredores del turno anterior. Toca ANOTAR CORREDORES.',
    );
  }
}

/// Revierte carreras, outs de corredores y bases de un turno cerrado.
Future<void> revertirCorredoresTurno(
  DatabaseExecutor txn,
  int juegoId,
  Map<String, Object?> t,
) async {
  final id = t['id'] as int;
  final carreras = (t['carreras'] as int?) ?? 0;
  if (carreras > 0) {
    final col = (t['propio'] as int?) == 1 ? 'carreras_propias' : 'carreras_rival';
    await txn.rawUpdate(
      'UPDATE juego_entrada SET $col = MAX(0, $col - ?) '
      'WHERE juego_id = ? AND numero = ?',
      [carreras, juegoId, t['entrada']],
    );
  }
  await txn.delete('turno_carrera', where: 'turno_id = ?', whereArgs: [id]);
  await txn.update(
    'turno_bate',
    {
      'bases_antes': null,
      'bases_despues': null,
      'carreras': 0,
      'outs_corredores': 0,
    },
    where: 'id = ?',
    whereArgs: [id],
  );
}

Future<void> _aplicarMovimientos(
  DatabaseExecutor txn,
  int juegoId,
  int turnoId,
  List<Map<String, dynamic>> movs,
) async {
  final t = await txn.query(
    'turno_bate',
    where: 'id = ?',
    whereArgs: [turnoId],
    limit: 1,
  );
  if (t.isEmpty) throw StateError('El turno ya no existe.');
  final turno = t.first;
  final resultado = turno['resultado'] as String?;
  if (resultado == null) throw StateError('El turno todavia esta abierto.');
  if (turno['bases_despues'] != null) {
    throw StateError('Los corredores de este turno ya estan registrados.');
  }
  final antes = _parsearBases(turno['bases_antes'] as String?);
  final bateadorId = turno['bateador_id'] as int;
  final lanzadorId = turno['lanzador_id'] as int?;
  final propio = (turno['propio'] as int?) == 1;
  final entrada = turno['entrada'] as int;

  final destinos = <int, String>{
    for (final m in movs) m['origen'] as int: m['destino'] as String,
  };
  final nuevas = <List<int?>?>[null, null, null];
  final anotan = <List<int?>>[];
  var outsExtra = 0;

  void mover(int origen, String d, List<int?> e) {
    if (d == 'out') {
      if (origen > 0) outsExtra++;
      return;
    }
    if (d == 'anota') {
      anotan.add(e);
      return;
    }
    final base = d == 'queda' ? origen : int.parse(d);
    if (base < 1 || base > 3) throw StateError('Destino invalido.');
    if (base < origen) throw StateError('Un corredor no puede retroceder.');
    if (nuevas[base - 1] != null) {
      throw StateError('Dos jugadores no pueden quedar en la misma base.');
    }
    nuevas[base - 1] = e;
  }

  for (var b = 1; b <= 3; b++) {
    final e = antes[b - 1];
    if (e == null) continue;
    mover(b, destinos[b] ?? 'queda', e);
  }
  final destBateador = _outsBateador.contains(resultado)
      ? 'out'
      : (destinos[0] ?? _destinoBateador(resultado));
  mover(0, destBateador, <int?>[bateadorId, lanzadorId, resultado == 'error' ? 0 : 1]);

  var rbi = _conImpulsada.contains(resultado);
  if (resultado == 'out_roletazo' && outsExtra > 0) rbi = false;

  for (final e in anotan) {
    await txn.insert('turno_carrera', {
      'turno_id': turnoId,
      'juego_id': juegoId,
      'corredor_id': e[0],
      'impulsor_id': rbi ? bateadorId : null,
      'lanzador_id': e[1],
      'limpia': e[2] ?? 1,
    });
  }

  final n = anotan.length;
  if (n > 0) {
    final col = propio ? 'carreras_propias' : 'carreras_rival';
    await txn.rawInsert(
      'INSERT OR IGNORE INTO juego_entrada '
      '(juego_id, numero, carreras_propias, carreras_rival) VALUES (?, ?, 0, 0)',
      [juegoId, entrada],
    );
    await txn.rawUpdate(
      'UPDATE juego_entrada SET $col = $col + ? WHERE juego_id = ? AND numero = ?',
      [n, juegoId, entrada],
    );
  }

  await txn.update(
    'turno_bate',
    {
      'bases_despues': jsonEncode(nuevas),
      'carreras': n,
      'outs_corredores': outsExtra,
    },
    where: 'id = ?',
    whereArgs: [turnoId],
  );

  if (outsExtra > 0) {
    final j = await txn.query(
      'juego',
      columns: ['entrada_actual', 'mitad_actual', 'outs_actuales'],
      where: 'juego_id = ?',
      whereArgs: [juegoId],
      limit: 1,
    );
    final ent = (j.first['entrada_actual'] as int?) ?? 1;
    final mi = (j.first['mitad_actual'] as String?) ?? 'alta';
    final outs = (j.first['outs_actuales'] as int?) ?? 0;
    final hayAccion = await txn.query(
      'juego_accion',
      columns: ['id'],
      where: "juego_id = ? AND tipo = 'out_turno' AND ref_id = ?",
      whereArgs: [juegoId, turnoId],
      limit: 1,
    );
    if (hayAccion.isEmpty) {
      await txn.insert('juego_accion', {
        'juego_id': juegoId,
        'tipo': 'out_turno',
        'equipo': null,
        'delta': 0,
        'entrada_antes': ent,
        'mitad_antes': mi,
        'outs_antes': outs,
        'ref_id': turnoId,
        'creado_ms': DateTime.now().millisecondsSinceEpoch,
      });
    }
    final nuevos = outs + outsExtra;
    if (nuevos >= 3) {
      if (mi == 'alta') {
        await _fijarEstado(txn, juegoId, ent, 'baja', 0);
      } else {
        await txn.rawInsert(
          'INSERT OR IGNORE INTO juego_entrada '
          '(juego_id, numero, carreras_propias, carreras_rival) VALUES (?, ?, 0, 0)',
          [juegoId, ent + 1],
        );
        await _fijarEstado(txn, juegoId, ent + 1, 'alta', 0);
      }
    } else {
      await _fijarEstado(txn, juegoId, ent, mi, nuevos);
    }
  }
}

extension CorredoresDB on DatabaseHelper {
  /// Turno cerrado cuyos corredores faltan por registrar, o null.
  Future<Map<String, dynamic>?> obtenerPendienteCorredores(int juegoId) async {
    final db = await database;
    final r = await db.rawQuery('''
      SELECT t.id, t.resultado, t.bases_antes, t.bases_despues,
             b.nombre AS bateador_nombre, b.numero AS bateador_numero,
             g.outs_actuales
      FROM turno_bate t
      JOIN jugador b ON b.jugador_id = t.bateador_id
      JOIN juego g ON g.juego_id = t.juego_id
      WHERE t.juego_id = ? AND t.resultado IS NOT NULL
      ORDER BY t.id DESC
      LIMIT 1
    ''', [juegoId]);
    if (r.isEmpty) return null;
    final f = r.first;
    if (f['bases_antes'] == null || f['bases_despues'] != null) return null;
    final bases = _parsearBases(f['bases_antes'] as String?);
    final corredores = <Map<String, dynamic>>[];
    for (var i = 0; i < 3; i++) {
      final b = bases[i];
      if (b == null) continue;
      final p = await db.query(
        'jugador',
        columns: ['nombre', 'numero'],
        where: 'jugador_id = ?',
        whereArgs: [b[0]],
        limit: 1,
      );
      corredores.add({
        'base': i + 1,
        'nombre': p.isEmpty ? '?' : p.first['nombre'],
        'numero': p.isEmpty ? null : p.first['numero'],
      });
    }
    return {
      'turno_id': f['id'],
      'resultado': f['resultado'],
      'bateador_nombre': f['bateador_nombre'],
      'bateador_numero': f['bateador_numero'],
      'outs': (f['outs_actuales'] as int?) ?? 0,
      'corredores': corredores,
    };
  }

  /// movs: lista de {origen: 0..3 (0 = bateador), destino: queda|1|2|3|anota|out}
  Future<void> resolverCorredores(
    int juegoId,
    int turnoId,
    List<Map<String, dynamic>> movs,
  ) async {
    final db = await database;
    await db.transaction((txn) async {
      final e = await txn.query(
        'juego',
        columns: ['estado'],
        where: 'juego_id = ?',
        whereArgs: [juegoId],
        limit: 1,
      );
      if (e.isEmpty) throw StateError('El juego ya no existe.');
      if (e.first['estado'] != 'en_juego') throw StateError('Este juego ya termino.');
      await _aplicarMovimientos(txn, juegoId, turnoId, movs);
    });
  }
}